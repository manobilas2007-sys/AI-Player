package dev.aiplayer.client;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.PlayerEntityModel;

/** Only modifies the vanilla Steve arm while food is being consumed. */
public final class CompanionModel extends PlayerEntityModel<CompanionEntity> {
    public CompanionModel(ModelPart root) { super(root,false); }
    @Override public void setAngles(CompanionEntity entity, float limbAngle, float limbDistance,
                                    float animationProgress, float headYaw, float headPitch) {
        super.setAngles(entity,limbAngle,limbDistance,animationProgress,headYaw,headPitch);
        if(entity.attackVisualTicks()>0 && !entity.isEating()) {
            float phase=(8-entity.attackVisualTicks()+animationProgress-entity.age)/8.0f;
            phase=Math.max(0,Math.min(1,phase));
            rightArm.pitch=-0.35f-(float)Math.sin(phase*Math.PI)*1.9f;
            rightArm.yaw=-0.6f+(float)Math.sin(phase*Math.PI)*0.9f;
            rightArm.roll=0.12f;
        } else if(entity.isWorkingVisual() && !entity.isEating()) {
            rightArm.pitch=-1.05f+(float)Math.sin(animationProgress*1.05f)*0.85f;
            rightArm.yaw=-0.12f;
            rightArm.roll=0.05f;
        }
        if (entity.isEating()) {
            rightArm.pitch = -1.30f + (float)Math.sin(animationProgress*1.5f)*0.12f;
            rightArm.yaw = -0.45f;
            rightArm.roll = -0.08f;
        }
        rightSleeve.copyTransform(rightArm);
    }
}
