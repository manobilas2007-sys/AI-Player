package dev.aiplayer.test;

import dev.aiplayer.AIPlayer;
import dev.aiplayer.ai.Mode;
import dev.aiplayer.entity.CompanionEntity;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.Enchantments;
import java.util.UUID;

public class CompanionTests implements FabricGameTest {
    private CompanionEntity npc(TestContext c) {return c.spawnEntity(AIPlayer.COMPANION,new BlockPos(2,2,2));}
    @GameTest(templateName=EMPTY_STRUCTURE)
    public void persistence(TestContext c) {
        CompanionEntity a=npc(c);UUID id=UUID.randomUUID();
        NbtCompound initial=new NbtCompound();a.writeCustomDataToNbt(initial);initial.putUuid("Owner",id);
        a.readCustomDataFromNbt(initial);a.setMode(Mode.WAIT);a.autoEquip=false;
        ItemStack sword=new ItemStack(Items.DIAMOND_SWORD);sword.setDamage(75);sword.addEnchantment(Enchantments.SHARPNESS,2);
        a.equipStack(EquipmentSlot.MAINHAND,sword);a.backpack.setStack(26,new ItemStack(Items.IRON_INGOT,37));
        a.equipStack(EquipmentSlot.CHEST,new ItemStack(Items.IRON_CHESTPLATE));
        NbtCompound saved=new NbtCompound();a.writeCustomDataToNbt(saved);
        CompanionEntity b=AIPlayer.COMPANION.create(c.getWorld());b.readCustomDataFromNbt(saved);
        c.assertTrue(id.equals(b.ownerId()),"Owner UUID lost");
        c.assertTrue(b.mode()==Mode.WAIT && !b.autoEquip,"Mode/options lost");
        c.assertTrue(b.backpack.getStack(26).isOf(Items.IRON_INGOT) && b.backpack.getStack(26).getCount()==37,"Backpack changed");
        c.assertTrue(b.getMainHandStack().getDamage()==75 && b.getMainHandStack().hasEnchantments(),"Durability/enchantments lost");
        c.assertTrue(b.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.IRON_CHESTPLATE),"Armor lost");
        c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE)
    public void equipmentConservesItems(TestContext c) {
        CompanionEntity a=npc(c);a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_SWORD));
        a.backpack.setStack(0,new ItemStack(Items.DIAMOND_SWORD));
        a.backpack.setStack(1,new ItemStack(Items.DIAMOND_CHESTPLATE));
        for(int i=2;i<27;i++)a.backpack.setStack(i,new ItemStack(Items.COBBLESTONE,64));
        a.optimizeEquipment();a.optimizeEquipment();
        c.assertTrue(a.getMainHandStack().isOf(Items.DIAMOND_SWORD),"Weapon not equipped");
        c.assertTrue(a.backpack.getStack(0).isOf(Items.WOODEN_SWORD),"Old weapon lost or duplicate");
        c.assertTrue(a.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.DIAMOND_CHESTPLATE),"Armor not equipped");
        c.assertTrue(a.backpack.getStack(1).isEmpty(),"Armor duplicated");
        int count=0;for(int i=0;i<27;i++)count+=a.backpack.getStack(i).getCount();
        c.assertTrue(count==25*64+1,"Inventory conservation failed");c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,tickLimit=40)
    public void realCombatAndDurability(TestContext c) {
        CompanionEntity a=npc(c);a.autoEquip=false;a.setAiDisabled(true);
        var target=c.spawnEntity(EntityType.ZOMBIE,new BlockPos(3,2,2));target.setAiDisabled(true);target.setInvulnerable(false);
        a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.DIAMOND_SWORD));
        a.equipStack(EquipmentSlot.CHEST,new ItemStack(Items.IRON_CHESTPLATE));
        c.runAtTick(3,()->{
            float before=target.getHealth();boolean hit=a.tryAttack(target);
            c.assertTrue(hit && target.getHealth()<before-4,"Real weapon damage missing");
            c.assertTrue(a.getMainHandStack().getDamage()==1,"Weapon durability not consumed");
            a.damage(c.getWorld().getDamageSources().mobAttack(target),6);
            c.assertTrue(a.getEquippedStack(EquipmentSlot.CHEST).getDamage()>0,"Armor durability not consumed");
            c.complete();
        });
    }
    @GameTest(templateName=EMPTY_STRUCTURE,tickLimit=180)
    public void navigationClimbsBlock(TestContext c) {
        for(int x=0;x<8;x++)for(int z=0;z<8;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.STONE);
        for(int x=4;x<8;x++)for(int z=0;z<8;z++)c.setBlockState(new BlockPos(x,2,z),Blocks.STONE);
        CompanionEntity a=npc(c);
        BlockPos dest=c.getAbsolutePos(new BlockPos(6,3,2));
        c.runAtTick(5,()->a.getNavigation().startMovingTo(dest.getX()+0.5,dest.getY(),dest.getZ()+0.5,1.0));
        c.runAtTick(140,()->{
            c.assertTrue(a.getY()>=dest.getY()-0.1 && a.squaredDistanceTo(dest.getX()+0.5,dest.getY(),dest.getZ()+0.5)<4,"Did not climb one-block ledge");
            c.complete();
        });
    }

    @GameTest(templateName=EMPTY_STRUCTURE)
    public void ownershipAndRealSlots(TestContext c) {
        CompanionEntity a=npc(c);
        var owner=c.createMockSurvivalPlayer();owner.setPosition(a.getPos());
        owner.setStackInHand(net.minecraft.util.Hand.MAIN_HAND,new ItemStack(Items.STICK));
        a.interact(owner,net.minecraft.util.Hand.MAIN_HAND);
        c.assertTrue(a.isOwner(owner),"Taming failed");
        c.assertTrue(owner.getMainHandStack().isEmpty(),"Taming did not consume stick");
        var menu=new dev.aiplayer.screen.CompanionMenu(10,owner.getInventory(),a);
        a.backpack.setStack(0,new ItemStack(Items.DIAMOND,12));
        menu.quickMove(owner,0);
        c.assertTrue(a.backpack.getStack(0).isEmpty() && owner.getInventory().count(Items.DIAMOND)==12,"Real slot withdrawal failed");
        for(int i=33;i<69;i++)if(menu.slots.get(i).getStack().isOf(Items.DIAMOND))menu.quickMove(owner,i);
        c.assertTrue(a.backpack.count(Items.DIAMOND)==12 && owner.getInventory().count(Items.DIAMOND)==0,"Real slot deposit failed");
        var stranger=c.createMockCreativePlayer();stranger.setPosition(a.getPos());
        c.assertFalse(menu.canUse(stranger),"Non-owner accessed backpack");
        c.assertFalse(menu.onButtonClick(stranger,2),"Non-owner issued order");
        c.assertTrue(menu.onButtonClick(owner,2) && a.mode()==Mode.WAIT,"Owner order failed");
        menu.onClosed(owner);c.assertFalse(a.menuOpen(),"Menu lock leaked");c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,tickLimit=100)
    public void monsterRecognizesCompanion(TestContext c) {
        for(int x=0;x<8;x++)for(int z=0;z<8;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.STONE);
        CompanionEntity a=npc(c);
        var zombie=c.spawnEntity(EntityType.ZOMBIE,new BlockPos(5,2,2));
        zombie.equipStack(EquipmentSlot.HEAD,new ItemStack(Items.IRON_HELMET));
        c.runAtTick(60,()->{c.assertTrue(zombie.getTarget() instanceof CompanionEntity,"Zombie did not target companion");c.complete();});
    }

    @GameTest(templateName=EMPTY_STRUCTURE, tickLimit=95)
    public void consumesRealFoodAndRestoresWeapon(TestContext c) {
        CompanionEntity a=npc(c);
        NbtCompound data=new NbtCompound();a.writeCustomDataToNbt(data);
        data.putUuid("Owner",UUID.randomUUID());a.readCustomDataFromNbt(data);
        a.autoCraft=false;a.autoEquip=false;a.setMode(Mode.WAIT);
        a.setHealth(10);
        a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.IRON_SWORD));
        a.backpack.setStack(0,new ItemStack(Items.COOKED_BEEF,3));
        c.runAtTick(70,()->{
            c.assertTrue(a.getHealth()>10,"Food did not heal companion");
            c.assertTrue(a.getMainHandStack().isOf(Items.IRON_SWORD),"Sword was not restored after eating");
            c.assertTrue(a.backpack.count(Items.COOKED_BEEF)==2,"Food duplicated or not consumed");
            c.complete();
        });
    }
    @GameTest(templateName=EMPTY_STRUCTURE)
    public void ownerAttackTargetIsPrioritized(TestContext c) {
        CompanionEntity a=npc(c);
        var slime=c.spawnEntity(EntityType.SLIME,new BlockPos(4,2,2));
        a.markOwnerAttack(slime);
        c.assertTrue(a.getTarget()==slime,"Companion did not select owner's target");
        c.assertTrue(dev.aiplayer.ai.CompanionGoal.isNaturallyHostile(slime),"Slime is not recognized as hostile");
        c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE, tickLimit=200)
    public void picksUpDroppedItemsWithoutCopies(TestContext c) {
        CompanionEntity a=npc(c);
        NbtCompound data=new NbtCompound();a.writeCustomDataToNbt(data);
        data.putUuid("Owner",UUID.randomUUID());a.readCustomDataFromNbt(data);
        a.autoCraft=false;
        var item=new net.minecraft.entity.ItemEntity(c.getWorld(),a.getX(),a.getY(),a.getZ(),new ItemStack(Items.IRON_INGOT,5));
        c.getWorld().spawnEntity(item);
        c.runAtTick(80,()->{
            c.assertTrue(a.backpack.count(Items.IRON_INGOT)==5,"Drops were not collected into the backpack");
            c.assertTrue(!item.isAlive(),"Collected drop still exists (duplication)");
            c.complete();
        });
    }
    @GameTest(templateName=EMPTY_STRUCTURE, tickLimit=110)
    public void miningSpawnsLootInsteadOfRemoteInsertion(TestContext c) {
        for(int x=0;x<6;x++)for(int z=0;z<6;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.STONE);
        CompanionEntity a=npc(c);a.setAiDisabled(true);a.autoLoot=false;a.autoCraft=false;
        BlockPos relative=new BlockPos(3,2,2);
        c.setBlockState(relative,Blocks.OAK_LOG);
        BlockPos target=c.getAbsolutePos(relative);
        var mining=new dev.aiplayer.ai.PhysicalMining(a);
        for(int tick=5;tick<=80;tick++)c.runAtTick(tick,()->mining.tick(target));
        c.runAtTick(6,()->c.assertTrue(c.getWorld().getBlockState(target).isOf(Blocks.OAK_LOG),"Bare-hand break was instant"));
        c.runAtTick(85,()->{
            c.assertTrue(c.getWorld().getBlockState(target).isAir(),"Timed mining failed");
            c.assertTrue(a.backpack.count(Items.OAK_LOG)==0,"Loot teleported to inventory");
            int total=c.getWorld().getEntitiesByClass(net.minecraft.entity.ItemEntity.class,
                new net.minecraft.util.math.Box(target).expand(3),e -> e.getStack().isOf(Items.OAK_LOG))
                .stream().mapToInt(e -> e.getStack().getCount()).sum();
            c.assertTrue(total==1,"Expected exactly one physical log drop");c.complete();
        });
    }
    @GameTest(templateName=EMPTY_STRUCTURE, tickLimit=40)
    public void pickupCountsWoodAfterInventoryTransfer(TestContext c) {
        for(int x=0;x<6;x++)for(int z=0;z<6;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.STONE);
        CompanionEntity a=npc(c);a.setAiDisabled(true);a.autoCraft=false;a.autoEquip=false;
        NbtCompound n=new NbtCompound();a.writeCustomDataToNbt(n);n.putUuid("Owner",UUID.randomUUID());a.readCustomDataFromNbt(n);
        a.gathering().start(dev.aiplayer.ai.ResourceGathering.Kind.WOOD,8,false);
        var drop=new net.minecraft.entity.ItemEntity(c.getWorld(),a.getX(),a.getY(),a.getZ(),new ItemStack(Items.OAK_LOG,3));
        drop.setPickupDelay(0);c.getWorld().spawnEntity(drop);
        c.runAtTick(25,()->{
            c.assertTrue(a.backpack.count(Items.OAK_LOG)==3,"Pickup lost items");
            c.assertTrue(a.gathering().progress()==3,"Pickup lost item identity before counting");
            c.assertTrue(!drop.isAlive(),"Pickup duplicated items");c.complete();
        });
    }
    @GameTest(templateName=EMPTY_STRUCTURE)
    public void reloadPreservesBenchWithoutValidRecipe(TestContext c) {
        CompanionEntity a=npc(c);
        BlockPos bench=c.getAbsolutePos(new BlockPos(3,2,2));
        NbtCompound saved=new NbtCompound();saved.putLong("OwnedBench",bench.asLong());
        NbtCompound brokenRecipe=new NbtCompound();brokenRecipe.putString("Result","broken recipe");
        saved.put("CraftSession",brokenRecipe);
        a.crafting().readNbt(saved);
        c.assertTrue(a.crafting().isWorking(),"Bench recovery lost on invalid saved recipe");
        NbtCompound again=new NbtCompound();a.crafting().writeNbt(again);
        c.assertTrue(again.contains("OwnedBench") && again.getLong("OwnedBench")==bench.asLong(),"Bench identity lost");
        c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE)
    public void autonomyDoesNotDependOnExactTick(TestContext c) {
        CompanionEntity a=npc(c);a.autoSurvive=false;a.autoCraft=true;a.setMode(Mode.GUARD);
        a.age=37;a.gathering().tick();
        c.assertTrue(a.gathering().kind()==dev.aiplayer.ai.ResourceGathering.Kind.WOOD,"Missed automatic wood collection at a non-multiple tick");
        a.gathering().cancel();a.setMode(Mode.WAIT);a.age=1000;a.gathering().tick();
        c.assertTrue(!a.gathering().active(),"Autonomy ignored WAIT command");c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE, tickLimit=500)
    public void craftingKeepsBenchAcrossRecipes(TestContext c) {
        for(int x=0;x<7;x++)for(int z=0;z<7;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.STONE);
        CompanionEntity a=npc(c);a.setAiDisabled(true);
        NbtCompound n=new NbtCompound();a.writeCustomDataToNbt(n);n.putUuid("Owner",UUID.randomUUID());a.readCustomDataFromNbt(n);
        a.autoSurvive=false;a.autoEquip=false;
        a.backpack.setStack(0,new ItemStack(Items.OAK_PLANKS,32));
        a.backpack.setStack(1,new ItemStack(Items.STICK,16));
        a.backpack.setStack(2,new ItemStack(Items.CRAFTING_TABLE));
        final long[] bench={0};
        c.runAtTick(75,()->{
            NbtCompound state=new NbtCompound();a.crafting().writeNbt(state);
            c.assertTrue(state.contains("OwnedBench"),"Bench removed after first recipe");bench[0]=state.getLong("OwnedBench");
            c.assertTrue(a.backpack.count(Items.WOODEN_PICKAXE)==1,"First tool missing");
            c.assertFalse(a.isWorkingVisual(),"Crafting incorrectly plays block-breaking animation");
        });
        c.runAtTick(115,()->{
            NbtCompound state=new NbtCompound();a.crafting().writeNbt(state);
            c.assertTrue(state.contains("OwnedBench") && state.getLong("OwnedBench")==bench[0],"Bench not reused for second recipe");
            c.assertTrue(a.backpack.count(Items.WOODEN_AXE)==1,"Second tool missing");
            c.assertTrue(c.getWorld().getBlockState(BlockPos.fromLong(bench[0])).isOf(Blocks.CRAFTING_TABLE),"Bench is not physically present");
        });
        c.runAtTick(450,()->{
            c.assertTrue(a.backpack.count(Items.WOODEN_SWORD)==1,"Last tool missing");
            c.assertTrue(a.backpack.count(Items.CRAFTING_TABLE)==1,"Bench not physically recovered");c.complete();
        });
    }

    @GameTest(templateName=EMPTY_STRUCTURE)
    public void combatInterruptsAxeWithSwordAndRestoresMiningTool(TestContext c) {
        CompanionEntity a=npc(c);a.setAiDisabled(true);
        a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.IRON_AXE));
        a.backpack.setStack(0,new ItemStack(Items.IRON_SWORD));
        a.gathering().start(dev.aiplayer.ai.ResourceGathering.Kind.WOOD,8,false);
        var target=c.spawnEntity(EntityType.ZOMBIE,new BlockPos(3,2,2));
        target.setAiDisabled(true);
        a.markWorking();a.tryAttack(target);
        c.assertTrue(a.getMainHandStack().isOf(Items.IRON_SWORD),"Active wood task kept axe in combat");
        c.assertTrue(!a.isWorkingVisual() && a.attackVisualTicks()>0,"Attack did not replace mining animation");
        c.assertTrue(a.backpack.getStack(0).isOf(Items.IRON_AXE),"Axe lost during combat switch");
        a.equipMiningTool(Blocks.OAK_LOG.getDefaultState());
        c.assertTrue(a.getMainHandStack().isOf(Items.IRON_AXE),"Axe not restored for wood");
        c.assertTrue(a.backpack.getStack(0).isOf(Items.IRON_SWORD),"Sword lost during mining switch");
        c.complete();
    }
    @GameTest(templateName=EMPTY_STRUCTURE,tickLimit=180)
    public void foodTaskCollectsLooseWood(TestContext c) {
        for(int x=0;x<8;x++)for(int z=0;z<8;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.STONE);
        CompanionEntity a=npc(c);
        NbtCompound n=new NbtCompound();a.writeCustomDataToNbt(n);
        n.putUuid("Owner",UUID.randomUUID());a.readCustomDataFromNbt(n);
        a.autoCraft=false;a.autoSurvive=false;
        a.gathering().start(dev.aiplayer.ai.ResourceGathering.Kind.FOOD,3,false);
        BlockPos pos=c.getAbsolutePos(new BlockPos(5,2,2));
        var drop=new ItemEntity(c.getWorld(),pos.getX()+0.5,pos.getY(),pos.getZ()+0.5,new ItemStack(Items.SPRUCE_LOG,3));
        drop.setPickupDelay(0);c.getWorld().spawnEntity(drop);
        for(int tick=1;tick<=140;tick++)c.runAtTick(tick,()->a.gathering().tick());
        c.runAtTick(150,()->{
            c.assertTrue(a.backpack.count(Items.SPRUCE_LOG)==3 && !drop.isAlive(),"Loose wood ignored or duplicated while foraging");
            c.assertTrue(a.gathering().progress()==0,"Wood incorrectly counted as food");
            c.complete();
        });
    }
}
