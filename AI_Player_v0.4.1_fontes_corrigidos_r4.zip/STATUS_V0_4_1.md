# AI Player v0.4.1-dev — r4

Fontes corrigidos para Minecraft Java 1.20.1, Fabric e Java 17.

- Compilação Fabric e compileTestmodJava: aprovadas.
- Testes de comandos: 38/38 aprovados.
- Verificações de prioridades: 110/110 aprovadas.
- GameTests: 70/70 aprovados em duas rodadas com mundos novos.
- Terceira rodada: iniciada, resultado não confirmado após interrupção e limpeza do ambiente.

Os fontes deste pacote são os mesmos das duas rodadas aprovadas; a finalização alterou somente documentação. Os XMLs dessas rodadas não sobreviveram à limpeza. Consulte docs/VALIDACAO_V0_4_1.md para o registro e as limitações. Ainda requer teste manual no jogo/FCL.
