# AI Player v0.4.1-dev — r4

Base: AI_Player_v0.4.1_fontes_corrigidos_r3.zip. Minecraft Java 1.20.1, Fabric, Java 17, Gradle 8.7.

## Alterações

- Torres: descida física de um bloco por vez, somente removendo apoios próprios com piso sólido seguro imediatamente abaixo. Centralização antes de descer; compatibilidade com descida lateral salva e coleta física dos drops. Funciona sem inventar blocos de reserva.
- Pedra: avalia corredor 2×2 e posições alternativas antes de escolher a aproximação. Preserva bancadas, construções protegidas e piso da galeria.
- Madeira → pedra: volta à ordem original assim que a picareta necessária existe, sem esperar ferramentas opcionais. Pode sair de um tronco ou bancada isolados para colocar a mesa e continuar.
- Bancada: navega até posições de contato com o drop, inclusive ao lado de obstáculos. Tentativas bloqueadas têm limite efetivo e mantêm o registro de propriedade para retomada.
- Cinco novos GameTests: torre sem reserva; descida lateral salva; bancada protegida no acesso à pedra; fabricação após sair de um tronco; retomada com receita opcional pendente. Os 65 anteriores foram preservados.

Sem novas dependências. Versão interna mantida em 0.4.1-dev; r4 identifica a revisão dos fontes.

## Compilação

```sh
bash gradlew clean build compileTestmodJava runGametest --no-daemon
```

No GitHub, extraia os fontes na raiz incluindo `.github/workflows/build-fabric.yml`. O workflow também aceita ZIP v0.4.1 na raiz quando não há fontes extraídos, mas enviar apenas o ZIP não atualiza um workflow antigo que procura v0.4.0. Resultado: `build/libs/ai-player-0.4.1-dev.jar`.

Estado dos testes: `docs/VALIDACAO_V0_4_1.md`. ZIP de fontes, sem JAR do mod. Documentos de versões anteriores são históricos.
