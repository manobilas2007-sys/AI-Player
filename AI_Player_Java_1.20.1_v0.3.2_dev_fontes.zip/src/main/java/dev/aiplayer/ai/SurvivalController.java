package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/** Server-side survival actions. Transfers actual stacks; never creates food. */
public final class SurvivalController {
    private final CompanionEntity npc;
    private int eatingTicks;
    private int foodSlot = -1;

    public SurvivalController(CompanionEntity npc) { this.npc = npc; }
    public boolean isEating() { return foodSlot >= 0; }

    public void tick() {
        if (npc.getWorld().isClient || !npc.isAlive() || npc.ownerId() == null) return;
        if (isEating()) {
            if (npc.getAttacker() != null && npc.age - npc.getLastAttackedTime() < 15) {
                cancelEating();
            } else if (--eatingTicks <= 0) {
                finishEating();
            }
            return;
        }
        if (npc.autoLoot && npc.age % 10 == 0) collectNearby();
        if (npc.autoSurvive && npc.age % 20 == 0 && npc.getHealth() <= npc.getMaxHealth() * 0.65f
                && npc.getTarget() == null && !npc.menuOpen()) {
            startEating();
        }
    }

    private boolean edible(ItemStack stack) {
        if (stack.isEmpty() || !stack.isFood()) return false;
        if (stack.isOf(Items.ROTTEN_FLESH) || stack.isOf(Items.SPIDER_EYE)
                || stack.isOf(Items.POISONOUS_POTATO) || stack.isOf(Items.PUFFERFISH)
                || stack.isOf(Items.CHICKEN)) return false;
        return stack.getItem().getFoodComponent() != null;
    }

    private void startEating() {
        int bestSlot = -1, bestValue = -1;
        for (int i = 0; i < npc.backpack.size(); i++) {
            ItemStack stack = npc.backpack.getStack(i);
            if (!edible(stack)) continue;
            FoodComponent food = stack.getItem().getFoodComponent();
            if (food != null && food.getHunger() > bestValue) {
                bestSlot = i; bestValue = food.getHunger();
            }
        }
        if (bestSlot < 0) return;
        ItemStack food = npc.backpack.removeStack(bestSlot);
        ItemStack originalWeapon = npc.getMainHandStack();
        npc.backpack.setStack(bestSlot, originalWeapon);
        npc.equipStack(EquipmentSlot.MAINHAND, food);
        foodSlot = bestSlot;
        eatingTicks = 24; // Finish before vanilla's item use duration can consume it separately.
        npc.setEatingVisual(true);
        npc.getNavigation().stop();
        npc.setCurrentHand(Hand.MAIN_HAND);
    }

    private void finishEating() {
        ItemStack stack = npc.getMainHandStack();
        boolean bowl = stack.isOf(Items.MUSHROOM_STEW) || stack.isOf(Items.RABBIT_STEW)
                || stack.isOf(Items.BEETROOT_SOUP) || stack.isOf(Items.SUSPICIOUS_STEW);
        if (edible(stack)) {
            FoodComponent food = stack.getItem().getFoodComponent();
            stack.decrement(1);
            if (food != null) npc.heal(Math.max(2.0f, food.getHunger() * 0.8f));
        }
        restoreHand(stack);
        if (bowl) {
            ItemStack left=npc.backpack.addStack(new ItemStack(Items.BOWL));
            if(!left.isEmpty())npc.dropStack(left);
        }
    }

    public void cancelEating() {
        if (isEating()) restoreHand(npc.getMainHandStack());
    }

    private void restoreHand(ItemStack remainingFood) {
        if (foodSlot < 0) return;
        npc.clearActiveItem();
        ItemStack weapon = npc.backpack.removeStack(foodSlot);
        npc.equipStack(EquipmentSlot.MAINHAND, weapon);
        npc.backpack.setStack(foodSlot, remainingFood);
        npc.backpack.markDirty();
        foodSlot = -1;
        eatingTicks = 0;
        npc.setEatingVisual(false);
    }

    /** Pick up only physically nearby drops. The ItemEntity retains any remainder. */
    private void collectNearby() {
        for (ItemEntity drop : npc.getWorld().getEntitiesByClass(ItemEntity.class,
                npc.getBoundingBox().expand(1.2), e -> e.isAlive() && !e.cannotPickup() && !e.getStack().isEmpty())) {
            if (npc.squaredDistanceTo(drop) > 2.7) continue;
            ItemStack picked=drop.getStack().copy();
            ItemStack incoming=drop.getStack().copy();
            ItemStack remainder = npc.backpack.addStack(incoming);
            int accepted=drop.getStack().getCount()-remainder.getCount();
            if(accepted>0){picked.setCount(accepted);if(!drop.getCommandTags().contains("aiplayer_recovered_support"))npc.gathering().onCollected(picked);}
            if (remainder.isEmpty()) drop.discard();
            else drop.setStack(remainder);
        }
    }
}
