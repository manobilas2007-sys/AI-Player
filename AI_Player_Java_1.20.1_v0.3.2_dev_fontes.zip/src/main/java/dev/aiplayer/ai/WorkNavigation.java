package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.util.hit.HitResult;
import net.minecraft.registry.tag.BlockTags;

/** Work destinations are standable positions beside the target, never the solid target itself. */
public final class WorkNavigation {
    private WorkNavigation() {}
    public static boolean safePath(CompanionEntity npc, Path path, int floorY) {
        if(path==null || !path.reachesTarget())return false;
        for(int i=0;i<path.getLength();i++) {
            var n=path.getNode(i);
            if(n.y<floorY || !npc.getWorld().isChunkLoaded(new BlockPos(n.x,n.y,n.z)))return false;
        }
        return true;
    }
    public static boolean moveNear(CompanionEntity npc, BlockPos target, int groundY, double speed) {
        Path best=null;double score=Double.MAX_VALUE;
        // Search a small ring at the work surface. Reject partial routes and cave detours.
        for(int radius=1;radius<=2;radius++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++) {
            if(Math.max(Math.abs(dx),Math.abs(dz))!=radius)continue;
            for(int dy=1;dy>=-1;dy--) {
                BlockPos p=new BlockPos(target.getX()+dx,groundY+dy,target.getZ()+dz);
                if(!npc.getWorld().isChunkLoaded(p) || !npc.getWorld().getFluidState(p).isEmpty()
                    || !npc.getWorld().getBlockState(p).getCollisionShape(npc.getWorld(),p).isEmpty()
                    || !npc.getWorld().getBlockState(p.up()).getCollisionShape(npc.getWorld(),p.up()).isEmpty()
                    || !npc.getWorld().getBlockState(p.down()).isSolidBlock(npc.getWorld(),p.down()))continue;
                Path path=npc.getNavigation().findPathTo(p,0);
                if(!safePath(npc,path,Math.min(npc.getBlockY(),groundY)-2))continue;
                double value=path.getLength()+p.getSquaredDistance(target)*0.1;
                if(value<score){score=value;best=path;}
            }
            if(best!=null)break;
        }
        if(best==null){npc.getNavigation().stop();return false;}
        return npc.getNavigation().startMovingAlong(best,speed);
    }
    public static BlockPos leafBetween(CompanionEntity npc, Vec3d end) {
        var hit=npc.getWorld().raycast(new RaycastContext(npc.getEyePos(),end,
            RaycastContext.ShapeType.COLLIDER,RaycastContext.FluidHandling.NONE,npc));
        if(hit.getType()!=HitResult.Type.BLOCK)return null;
        BlockPos pos=hit.getBlockPos();
        return npc.getWorld().getBlockState(pos).isIn(BlockTags.LEAVES)?pos.toImmutable():null;
    }
}
