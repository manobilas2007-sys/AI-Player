package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.block.BlockState;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.*;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.GameRules;
import java.util.ArrayList;
import java.util.List;

/** Place only after a real jump clears the destination. Recover in reverse order. */
public final class TemporaryPillar {
    private record Placed(BlockPos pos, BlockState state) {}
    private final CompanionEntity npc;
    private final List<Placed> placed = new ArrayList<>();
    private BlockPos jumping;
    private int jumpStarted;
    public TemporaryPillar(CompanionEntity npc) { this.npc = npc; }
    public boolean isJumping() {return jumping!=null;}
    public boolean active() { return !placed.isEmpty() || jumping != null; }
    public boolean owns(BlockPos pos) { return placed.stream().anyMatch(p -> p.pos.equals(pos)); }
    public boolean climb() {
        if (!npc.getWorld().getGameRules().getBoolean(GameRules.DO_MOB_GRIEFING)) return false;
        if (placed.size() >= 20) return false;
        int slot = -1;
        for (int i=0;i<npc.backpack.size();i++) {
            ItemStack s=npc.backpack.getStack(i);
            if (s.isIn(ItemTags.LOGS) && s.getItem() instanceof BlockItem) {slot=i;break;}
        }
        if (slot<0) return false;
        if (jumping == null) {
            if (!npc.isOnGround()) return true;
            BlockPos p=npc.getBlockPos();
            if (!npc.getWorld().getBlockState(p).isAir()
                    || !npc.getWorld().getBlockState(p.up(2)).isAir()
                    || !npc.getWorld().getBlockState(p.down()).isSolidBlock(npc.getWorld(),p.down())) return false;
            // Stay centered enough that the whole body lands on the support.
            if (Math.abs(npc.getX()-p.getX()-0.5)>0.25 || Math.abs(npc.getZ()-p.getZ()-0.5)>0.25) {
                npc.getNavigation().startMovingTo(p.getX()+0.5,p.getY(),p.getZ()+0.5,0.7);return true;
            }
            jumping=p.toImmutable();jumpStarted=npc.age;
            npc.getNavigation().stop();npc.setVelocity(0,0.42,0);return true;
        }
        if (npc.age-jumpStarted>20) { jumping=null;return false; }
        if (npc.getY()<jumping.getY()+1.0) return true;
        if (!npc.getWorld().getBlockState(jumping).isAir()
                || !npc.getWorld().getOtherEntities(null,new Box(jumping)).isEmpty()) {jumping=null;return false;}
        ItemStack stack=npc.backpack.getStack(slot);
        BlockState state=((BlockItem)stack.getItem()).getBlock().getDefaultState();
        if (npc.getWorld().setBlockState(jumping,state,3)) {
            stack.decrement(1);npc.backpack.markDirty();placed.add(new Placed(jumping,state));
        }
        jumping=null;return true;
    }
    public boolean cleanup(PhysicalMining mining) {
        jumping=null;
        while (!placed.isEmpty()) {
            Placed p=placed.get(placed.size()-1);
            if (!npc.getWorld().isChunkLoaded(p.pos)) return true;
            if (!npc.getWorld().getBlockState(p.pos).equals(p.state)) {placed.remove(placed.size()-1);continue;}
            if (!npc.isOnGround()) return true;
            if (!mining.reachable(p.pos)) {
                if (npc.age%20==0) npc.getNavigation().startMovingTo(p.pos.getX()+0.5,p.pos.getY()+1,p.pos.getZ()+0.5,1);
                return true;
            }
            if (mining.tick(p.pos,true)) placed.remove(placed.size()-1);
            return true;
        }
        return false;
    }
    public void writeNbt(NbtCompound root) {
        NbtList list=new NbtList();
        for (Placed p:placed) {NbtCompound n=new NbtCompound();n.putLong("Pos",p.pos.asLong());n.putString("Block",net.minecraft.registry.Registries.BLOCK.getId(p.state.getBlock()).toString());list.add(n);}
        root.put("TemporaryPillar",list);
    }
    public void readNbt(NbtCompound root) {
        placed.clear();jumping=null;
        NbtList list=root.getList("TemporaryPillar",NbtElement.COMPOUND_TYPE);
        for(int i=0;i<Math.min(20,list.size());i++) {
            NbtCompound n=list.getCompound(i);
            BlockState state=net.minecraft.registry.Registries.BLOCK.get(new net.minecraft.util.Identifier(n.getString("Block"))).getDefaultState();
            placed.add(new Placed(BlockPos.fromLong(n.getLong("Pos")),state));
        }
    }
}
