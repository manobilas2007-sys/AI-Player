# AI Player v0.3.8-dev

Versão atual: [README_V0_3_8.md](README_V0_3_8.md). Os documentos abaixo são históricos.

# AI Player v0.3.7-dev

Versão atual: [README_V0_3_7.md](README_V0_3_7.md). Os documentos abaixo são históricos.

# AI Player v0.3.6-dev

Veja [README_V0_3_6.md](README_V0_3_6.md) para mudanças, compilação e limitações da versão atual.

> Versão deste pacote: **0.3.5-dev**. Leia README_V0_3_5.md para alterações, validação e limitações. O texto abaixo é histórico.

# AI Player Fabric 1.20.1 | v0.3.0-dev

**Leia primeiro [`README_V0_3.md`](README_V0_3.md). Esta é uma atualização de fontes não compilada.**

> **ATENÇÃO (v0.2.0-dev):** esta pasta contém alterações de código-fonte em desenvolvimento, NÃO compiladas nem testadas em Minecraft. O texto abaixo registra a versão original v0.1.0. Leia [README_V0_2.md](README_V0_2.md) e [docs/V0_2_DESENVOLVIMENTO.md](docs/V0_2_DESENVOLVIMENTO.md) antes de compilar.

# AI Player Java — 0.1.0 (primeira versão de testes)

Minecraft **Java 1.20.1**, **Fabric Loader 0.15.11 ou superior compatível**, **Java 17** e **Fabric API 0.92.2+1.20.1**.
Não funciona no Bedrock, Forge, NeoForge ou outras versões do Minecraft.

## Instalação no Fold Craft Launcher

1. Selecione/crie uma instalação Minecraft Java 1.20.1 com Fabric e Java 17.
2. Na pasta `mods` **da instalação que você vai abrir**, coloque `ai-player-0.1.0.jar` e o Fabric API para 1.20.1. Não coloque o ZIP de fontes nem o JAR de fontes em `mods`.
3. Abra um mundo de teste no Criativo. Procure **Invocar AI Player** na aba de ovos ou na busca do inventário.
4. Use o ovo no chão. Interaja com o NPC segurando um **graveto** para domesticar.
5. Interaja novamente para abrir o menu. A interação corresponde ao botão de usar item/botão direito nos controles do FCL.
6. Arraste os itens entre sua mochila e os 27 slots do companheiro. Os seis slots abaixo são: cabeça, peito, pernas, pés, mão principal e mão secundária.

Fabric API oficial, versão fixada:
https://maven.fabricmc.net/net/fabricmc/fabric-api/fabric-api/0.92.2+1.20.1/fabric-api-0.92.2+1.20.1.jar

Nesta versão o NPC é criado pelo ovo no Criativo; ainda não há geração natural ou receita de invocação no Survival. Depois de invocá-lo, pode mudar para Survival para testar normalmente.

## Comportamento implementado

- Humanoide Steve com modelo de jogador, renderizador de item na mão e armaduras vanilla. Usa assets já instalados do Minecraft; não há cópia dos sprites de arma do Bedrock.
- 30 pontos de vida. Dono por UUID; apenas ele pode abrir a mochila ou emitir ordens.
- **Seguir**: começa a acompanhar além de 15 blocos, aproxima-se até cerca de 8 e passeia pelo entorno. Reage a ataques recebidos.
- **Proteger**: acompanha e procura monstros visíveis próximos; também reage ao agressor recente do dono.
- **Esperar**: interrompe o passeio/acompanhamento, mas permite defesa e retirada em perigo.
- **Vir aqui**: procura um espaço livre com apoio perto do dono. Não teleporta dentro de blocos ou em fluidos.
- Navegação vanilla para contornar obstáculos, subir um bloco e flutuar/nadar na superfície. Caminhos recalculados com intervalo; não escava nem constrói pontes nesta versão.
- Recuperação por teleporte se exceder 32 blocos ou ficar sem progresso por cerca de 5 segundos durante acompanhamento, desde que ambos estejam carregados na mesma dimensão.
- Mochila real de 27 slots, equipamentos reais e transferência com arraste/Shift-click. O equipamento sai da mochila; não vira uma cópia visual.
- **Autoequipar** escolhe espadas/machados e armaduras usando dano/proteção, encantamentos de dano/Proteção e durabilidade relativa. Armaduras especiais e todos os encantamentos situacionais ainda não têm avaliação completa. Desative para manter escolhas manuais.
- Ataques corpo a corpo passam pelo sistema vanilla de dano e encantamentos, com desgaste das armas/armaduras. O intervalo básico é de 20 ticks (espadas) ou 25 ticks (machados); ainda não é um simulador completo do cooldown de jogador.
- Monstros `HostileEntity` recebem um objetivo de selecionar o companheiro. Endermen e piglins zumbificados mantêm sua neutralidade. IA especial de chefes e mobs de outros mods não é garantida.
- Com 8 pontos de vida ou menos, tenta recuar por uma rota vanilla em vez de continuar atacando. Ainda não come nem recupera vida automaticamente.
- NBT salva dono, nome do dono, mochila, modo e opção de equipamento. Vida, equipamentos, durabilidade e encantamentos usam também a persistência vanilla da entidade.
- Na morte, os itens da mochila e equipamentos podem cair no mundo; Maldição do Desaparecimento é respeitada.

## Limites desta entrega

Ainda **não implementados**: coleta de madeira, mineração, scanner de minérios, fabricação, comida/animação de alimentação, construção, tochas, alteração de terreno, arcos/bestas, skins personalizadas, controle remoto por item e tarefas avançadas com retomada.

Aguardar/seguir/proteger não são uma implementação das futuras tarefas de trabalho. Não há simulação de mineração escondida no código.

Não mantém chunks carregados. Não recupera NPC de chunk já descarregado nem o transporta entre dimensões. A navegação vanilla não garante saída de qualquer caverna, travessia de grandes oceanos ou fuga perfeita de creepers. Não houve medição de FPS no Android.

Menu reúne ordens, mochila e equipamento na mesma tela. Durante a edição da mochila, a troca automática e o passeio ficam pausados; defesa ainda pode acontecer. Se necessário, reduza a escala da interface do Minecraft para caber na tela.

## Validação

Veja `docs/TESTES.md` para os resultados efetivamente obtidos. Compilar não equivale a testar o renderizador nem o Fold Craft Launcher.

## Código-fonte e desenvolvimento

- `./gradlew build` — JAR remapeado instalável em `build/libs/ai-player-0.1.0.jar`.
- `./gradlew runGametest` — testes automatizados no servidor Minecraft, com mod de testes separado em `src/testmod`.
- `./gradlew runClient` — ambiente gráfico de desenvolvimento, se disponível.

Requer JDK 17 e acesso aos repositórios Gradle/Fabric/Mojang. O ZIP contém o Gradle Wrapper, não o JDK nem os arquivos proprietários do jogo.

Leia `docs/ANALISE_BEDROCK.md` para a análise da base anterior e organização da migração.
