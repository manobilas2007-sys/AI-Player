import dev.aiplayer.commands.PortugueseOrderParser;
import static dev.aiplayer.commands.PortugueseOrderParser.Action.*;
public class PortugueseOrderParserTest {
    private static void check(String text, PortugueseOrderParser.Action action, int qty) {
        var result=PortugueseOrderParser.parse(text);
        if(result.action()!=action || result.amount()!=qty)throw new AssertionError(text+" => "+result);
    }
    public static void main(String[] args) {
        check("você pode pega 10 tronco de madeira pra mim?", WOOD, 10);
        check("vc consegue pege 16 troncus de madeirra",WOOD,16);
        check("coleta 64 toras",WOOD,64);
        check("traga sessenta e quatro madeira",WOOD,64);
        check("busca duas toras",WOOD,2);
        check("traga duzentos e sessenta e quatro troncos",WOOD,264);
        check("arranje 11 tronco de madeira",WOOD,11);
        check("pegue 6 carnes",FOOD,6);
        check("coletar 10 alimentos",FOOD,10);
        check("cancelar tarefa",CANCEL,0);
        check("nao pega madeira",NONE,0);
        check("oi estou na floresta",NONE,0);
        check("pegue 900 madeira",NONE,0);
        System.out.println("13 testes do interpretador: OK");
    }
}
