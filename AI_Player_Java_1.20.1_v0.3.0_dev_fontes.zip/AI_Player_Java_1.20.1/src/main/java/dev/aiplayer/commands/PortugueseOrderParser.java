package dev.aiplayer.commands;

import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** A small offline command parser, not a generative language model. */
public final class PortugueseOrderParser {
    public enum Action { WOOD, FOOD, CANCEL, NONE }
    public record Order(Action action, int amount) {}
    private static final Pattern DIGITS = Pattern.compile("(?<![0-9])([0-9]{1,4})(?![0-9])");
    private PortugueseOrderParser() {}

    public static String normalize(String value) {
        String noAccents = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "");
        return noAccents.toLowerCase(Locale.ROOT)
                .replaceAll("[^a-z0-9]+", " ").trim().replaceAll(" +", " ");
    }
    private static int edits(String a, String b) {
        int[] old = new int[b.length() + 1];
        int[] now = new int[b.length() + 1];
        for (int j=0; j<=b.length(); j++) old[j]=j;
        for (int i=1; i<=a.length(); i++) {
            now[0]=i;
            for (int j=1; j<=b.length(); j++) now[j]=Math.min(Math.min(now[j-1]+1,old[j]+1),old[j-1]+(a.charAt(i-1)==b.charAt(j-1)?0:1));
            int[] swap=old; old=now; now=swap;
        }
        return old[b.length()];
    }
    private static boolean close(String token, String... options) {
        for(String option: options) {
            if(token.equals(option))return true;
            if(token.length()>=4 && option.length()>=4 && edits(token,option)<= (Math.min(token.length(),option.length())>=7?2:1))return true;
        }
        return false;
    }
    private static boolean containsAny(String[] words,String... options) {
        for(String word:words)if(close(word,options))return true;
        return false;
    }
    public static Order parse(String raw) {
        if(raw==null || raw.isBlank())return new Order(Action.NONE,0);
        String text=normalize(raw);
        String[] words=text.split(" ");
        boolean cancel=containsAny(words,"cancelar","cancela","pare","parar","interromper","desista");
        if(cancel && containsAny(words,"tarefa","coleta","madeira","troncos","trabalho","ordem","buscar","pegar"))
            return new Order(Action.CANCEL,0);
        boolean wood=containsAny(words,"madeira","madeiras","tronco","troncos","tora","toras","arvore","arvores","lenha");
        boolean food=containsAny(words,"comida","alimento","alimentos","carne","carnes");
        boolean request=containsAny(words,"pega","pegar","pegue","pege","apanha","apanhar","busca","buscar","busque","procura","procurar","coleta","coletar","colhe","colher","corta","cortar","traz","trazer","traga","arruma","arrumar","arranje","junta","juntar","consegue","consiga","obter","preciso","quero");
        if(!request || (!wood && !food))return new Order(Action.NONE,0);
        // Never interpret explicit negations as collection commands.
        if(text.matches(".*\\b(nao|nunca)\\s+(pega|pegar|coleta|coletar|busca|buscar|corta|cortar)\\b.*"))
            return new Order(Action.NONE,0);
        int amount=wood?8:4;
        Matcher found=DIGITS.matcher(text);
        if(found.find()) {
            amount=Integer.parseInt(found.group(1));
        } else if (text.contains("duzentos e sessenta e quatro")) amount=264;
        else if (text.contains("cento e vinte e oito")) amount=128;
        else if (text.contains("sessenta e quatro")) amount=64;
        else {
            String[] numberWords={"um","uma","dois","duas","tres","quatro","cinco","seis","sete","oito","nove","dez","quinze","vinte","trinta","quarenta","cinquenta","sessenta","cem"};
            int[] values={1,1,2,2,3,4,5,6,7,8,9,10,15,20,30,40,50,60,100};
            for(int i=0;i<numberWords.length;i++)if(containsAny(words,numberWords[i])){amount=values[i];break;}
        }
        if(amount<1 || amount>264) return new Order(Action.NONE,0);
        return new Order(wood?Action.WOOD:Action.FOOD,amount);
    }
}
