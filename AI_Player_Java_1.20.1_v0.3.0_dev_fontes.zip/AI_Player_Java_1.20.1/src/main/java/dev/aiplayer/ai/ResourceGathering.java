package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.Comparator;
import java.util.List;

/**
 * Limited, chunk-safe resource tasks. Only loaded trees and non-owned farm animals are targets.
 * Combat/retreat/eating always preempt this controller in CompanionGoal.
 */
public final class ResourceGathering {
    public enum Kind { NONE, WOOD, FOOD }
    private final CompanionEntity npc;
    private Kind kind=Kind.NONE, lastAutoKind=Kind.NONE;
    private int desired, gathered, lastAction, nextSearch, noProgressTicks, idleCooldown;
    private boolean manual;
    private BlockPos origin, tree;
    private AnimalEntity animal;
    private BlockPos waypoint;
    private int waypointIndex;
    private Vec3d lastLocation=Vec3d.ZERO;
    private int attackCooldown;

    public ResourceGathering(CompanionEntity npc) {this.npc=npc;}
    public boolean active() {return kind!=Kind.NONE;}
    public Kind kind() {return kind;}
    public int progress() {return gathered;}
    public int goal() {return desired;}
    private void tell(String text) {if(manual && npc.owner()!=null)npc.owner().sendMessage(Text.literal("[AI Player] "+text),false);}
    public void start(Kind task,int count,boolean fromPlayer) {
        if (task==Kind.NONE) {cancel(); return;}
        kind=task; desired=Math.max(1,Math.min(264,count)); gathered=0;
        manual=fromPlayer; if(!fromPlayer)lastAutoKind=task; origin=npc.getBlockPos().toImmutable(); tree=null; animal=null;waypoint=null;waypointIndex=0;
        lastAction=npc.age; nextSearch=0; noProgressTicks=0;attackCooldown=0;
        npc.getNavigation().stop();
        tell("Entendido! Vou buscar "+desired+(kind==Kind.WOOD?" troncos de madeira.":" alimentos."));
    }
    public void cancel() {if(active())tell("Tarefa cancelada ("+gathered+"/"+desired+").");finish(false);}
    private void finish(boolean done) {
        if(done)tell("Terminei! Consegui "+gathered+"/"+desired+(kind==Kind.WOOD?" troncos.":" alimentos."));
        kind=Kind.NONE;tree=null;animal=null;waypoint=null;npc.getNavigation().stop();
        if(done && manual && npc.owner()!=null)CompanionGoal.recall(npc,npc.owner());
        idleCooldown=npc.age+400;
    }
    /** Called by the movement goal only when there is no threat and the NPC is healthy. */
    public boolean tick() {
        if (!active()) {
            if(npc.age<idleCooldown || npc.age%160!=0 || !npc.autoSurvive || npc.mode()==Mode.WAIT || npc.menuOpen())return false;
            if(npc.owner()!=null && npc.squaredDistanceTo(npc.owner())>18*18)return false;
            boolean needFood=foodInBag()<3;
            boolean needWood=npc.autoCraft && woodInBag()<4 && planksInBag()<8;
            if(needFood && needWood) {
                // Don't starve for building resources or get stuck hunting forever for nonexistent animals.
                Kind next=npc.getHealth()<npc.getMaxHealth()*0.75 ? Kind.FOOD
                    : lastAutoKind==Kind.WOOD?Kind.FOOD:Kind.WOOD;
                start(next,next==Kind.FOOD?3:8,false);
            } else if(needFood)start(Kind.FOOD,3,false);
            else if(needWood)start(Kind.WOOD,8,false);
            else return false;
        }
        if(npc.menuOpen() || npc.isEating() || npc.getTarget()!=null)return true;
        if(attackCooldown>0)attackCooldown--;
        if(gathered>=desired){finish(true);return true;}
        if(origin!=null && npc.getBlockPos().getSquaredDistance(origin)>50*50) {
            tell("Saí da área segura de coleta.");finish(false);return true;
        }
        if(npc.age-lastAction>850) {tell("Não consegui avançar nesta tarefa; vou parar para não ficar preso.");finish(false);return true;}
        if(kind==Kind.WOOD)woodTick(); else foodTick();
        return true;
    }
    private int woodInBag() {
        int n=0;
        for(int i=0;i<npc.backpack.size();i++){ItemStack s=npc.backpack.getStack(i);if(s.isIn(ItemTags.LOGS))n+=s.getCount();}
        return n;
    }
    private int planksInBag() {
        int n=0;
        for(int i=0;i<npc.backpack.size();i++){ItemStack s=npc.backpack.getStack(i);if(s.isIn(ItemTags.PLANKS))n+=s.getCount();}
        return n;
    }
    private boolean foodItem(ItemStack item) {
        if(!item.isFood())return false;
        return !item.isOf(Items.ROTTEN_FLESH) && !item.isOf(Items.POISONOUS_POTATO)
            && !item.isOf(Items.SPIDER_EYE) && !item.isOf(Items.PUFFERFISH) && !item.isOf(Items.CHICKEN);
    }
    private int foodInBag() {
        int n=0;
        for(int i=0;i<npc.backpack.size();i++){ItemStack s=npc.backpack.getStack(i);if(foodItem(s))n+=s.getCount();}
        return n;
    }
    private static boolean isSoil(BlockState state) {
        return state.isIn(BlockTags.DIRT) || state.isOf(Blocks.GRASS_BLOCK)
             || state.isOf(Blocks.PODZOL) || state.isOf(Blocks.MYCELIUM);
    }
    private boolean safe(BlockPos p) {
        return npc.getWorld().isChunkLoaded(p) && p.getY()>npc.getWorld().getBottomY()+2
            && p.getY()<npc.getWorld().getTopY()-2;
    }
    private boolean treeBase(BlockPos p) {
        if(!safe(p) || !safe(p.up(3)) || !npc.getWorld().getBlockState(p).isIn(BlockTags.LOGS)
                || !isSoil(npc.getWorld().getBlockState(p.down())))return false;
        // A vertical trunk, connected to its own leaf canopy; horizontal logs near leaves do not qualify.
        int height=0;
        while(height<32 && safe(p.up(height)) && npc.getWorld().getBlockState(p.up(height)).isIn(BlockTags.LOGS))height++;
        if(height<3)return false;
        for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++) {
            BlockPos leaf=p.up(height).add(dx,dy,dz);
            if(safe(leaf) && npc.getWorld().getBlockState(leaf).isIn(BlockTags.LEAVES))return true;
        }
        return false;
    }
    private BlockPos findTree() {
        BlockPos center=npc.getBlockPos();
        BlockPos best=null;double score=Double.MAX_VALUE;
        // At most 13*13*5 candidate locations, only every few seconds on the server.
        for(int dx=-12;dx<=12;dx+=2)for(int dz=-12;dz<=12;dz+=2)for(int dy=-2;dy<=3;dy++) {
            BlockPos p=center.add(dx,dy,dz);
            if((origin!=null && p.getSquaredDistance(origin)>50*50) || !treeBase(p))continue;
            double d=p.getSquaredDistance(center);
            if(d<score){best=p.toImmutable();score=d;}
        }
        // Second pass at exact positions catches odd-offset trees without a full 50-block scan.
        if(best==null) for(int dx=-9;dx<=9;dx++)for(int dz=-9;dz++)for(int dy=-2;dy<=2;dy++) {
            BlockPos p=center.add(dx,dy,dz);
            if((origin!=null && p.getSquaredDistance(origin)>50*50)||!treeBase(p))continue;
            double d=p.getSquaredDistance(center);
            if(d<score){best=p.toImmutable();score=d;}
        }
        return best;
    }
    private void equipAxe() {
        if(npc.getMainHandStack().getItem() instanceof AxeItem)return;
        int best=-1;float speed=0;
        for(int i=0;i<npc.backpack.size();i++){
            ItemStack s=npc.backpack.getStack(i);
            if(s.getItem() instanceof AxeItem axe && s.getCount()==1) {
                float value=axe.getMaterial().getMiningSpeedMultiplier();
                if(value>speed){speed=value;best=i;}
            }
        }
        if(best>=0) {
            ItemStack selected=npc.backpack.removeStack(best);
            ItemStack old=npc.getMainHandStack();
            npc.equipStack(EquipmentSlot.MAINHAND,selected);
            npc.backpack.setStack(best,old);
        }
    }
    private boolean travelSearchPoint() {
        if(waypoint!=null && npc.squaredDistanceTo(Vec3d.ofCenter(waypoint))>4.5*4.5) {
            if(npc.age%30==0)npc.getNavigation().startMovingTo(waypoint.getX()+0.5,waypoint.getY(),waypoint.getZ()+0.5,1.15);
            return true;
        }
        waypoint=null;
        // Bounded outward search (not a scan of unloaded chunks). A manual order reaches farther.
        int[][] choices={{12,0},{0,12},{-12,0},{0,-12},{20,10},{-20,10},{20,-10},{-20,-10},
            {30,0},{0,30},{-30,0},{0,-30},{34,22},{-34,22},{34,-22},{-34,-22}};
        int limit=manual?choices.length:4;
        while(waypointIndex<limit) {
            int[] delta=choices[waypointIndex++];
            BlockPos base=origin.add(delta[0],0,delta[1]);
            for(int dy=2;dy>=-3;dy--) {
                BlockPos p=base.up(dy);
                if(!safe(p) || !safe(p.up()) || !safe(p.down()))continue;
                if(!npc.getWorld().getBlockState(p).isAir() || !npc.getWorld().getBlockState(p.up()).isAir()
                    || !npc.getWorld().getBlockState(p.down()).isSolidBlock(npc.getWorld(),p.down()))continue;
                waypoint=p.toImmutable();npc.getNavigation().startMovingTo(p.getX()+0.5,p.getY(),p.getZ()+0.5,1.15);
                lastAction=npc.age;return true;
            }
        }
        return false;
    }
    private void woodTick() {
        if(npc.age < nextSearch)return;
        if(tree==null || !safe(tree)){
            tree=findTree();nextSearch=npc.age+30;
            if(tree==null){
                if(travelSearchPoint())return;
                if(npc.age-lastAction>160){tell("Não encontrei árvores naturais acessíveis na região carregada.");finish(false);}
                return;
            }
            waypoint=null;
        }
        // A tree may have been chopped by the player while the NPC was walking to it.
        BlockPos cut=tree;
        int height=0;
        while(height<28 && safe(cut.up(height)) && !npc.getWorld().getBlockState(cut.up(height)).isIn(BlockTags.LOGS))height++;
        if(height>=28){tree=null;nextSearch=npc.age+25;return;}
        cut=cut.up(height);
        if(npc.squaredDistanceTo(Vec3d.ofCenter(cut))>3.6*3.6){
            if(npc.age%25==0)npc.getNavigation().startMovingTo(tree.getX()+0.5,tree.getY(),tree.getZ()+0.5,1.18);
            if(npc.age%40==0)checkStuck();
            return;
        }
        if(npc.age-lastAction<13)return;
        equipAxe();
        BlockState state=npc.getWorld().getBlockState(cut);
        if(!state.isIn(BlockTags.LOGS)) {tree=null;return;}
        if(!(npc.getWorld() instanceof ServerWorld sw))return;
        ItemStack tool=npc.getMainHandStack();
        List<ItemStack> drops=Block.getDroppedStacks(state,sw,cut,sw.getBlockEntity(cut),npc,tool);
        if(!npc.getWorld().breakBlock(cut,false,npc)) {tree=null;return;}
        int inserted=0;
        for(ItemStack item:drops){
            ItemStack keep=item.copy();int original=keep.getCount();
            ItemStack left=npc.backpack.addStack(keep);
            inserted+=original-left.getCount();
            if(!left.isEmpty())npc.dropStack(left);
        }
        gathered+=inserted;
        if(!tool.isEmpty() && tool.isDamageable())tool.damage(1,npc,e->e.sendEquipmentBreakStatus(EquipmentSlot.MAINHAND));
        npc.swingHand(Hand.MAIN_HAND);
        lastAction=npc.age;nextSearch=npc.age+16;
        // Clear the target only after the contiguous trunk has been exhausted.
        if(!npc.getWorld().getBlockState(cut.up()).isIn(BlockTags.LOGS))tree=null;
    }
    private void checkStuck() {
        Vec3d now=npc.getPos();
        if(now.squaredDistanceTo(lastLocation)<0.18)noProgressTicks+=40;else noProgressTicks=0;
        lastLocation=now;
        if(noProgressTicks>=160){tree=null;noProgressTicks=0;nextSearch=npc.age+25;}
    }
    private boolean prey(AnimalEntity a) {
        return a.isAlive() && !a.isBaby() && (a instanceof CowEntity || a instanceof PigEntity
                || a instanceof SheepEntity || a instanceof RabbitEntity);
    }
    private void foodTick() {
        if(npc.age<nextSearch)return;
        if(animal==null || !prey(animal) || animal.squaredDistanceTo(npc)>25*25) {
            animal=npc.getWorld().getEntitiesByClass(AnimalEntity.class,npc.getBoundingBox().expand(14),this::prey)
                    .stream().min(Comparator.comparingDouble(npc::squaredDistanceTo)).orElse(null);
            if(animal==null) {
                if(npc.age-lastAction>240){tell("Não encontrei animais adequados por perto.");finish(false);}
                nextSearch=npc.age+45;return;
            }
        }
        if(npc.squaredDistanceTo(animal)>2.9*2.9) {
            if(npc.age%20==0)npc.getNavigation().startMovingTo(animal,1.23);
            return;
        }
        npc.getLookControl().lookAt(animal,30,30);
        if(attackCooldown==0){
            npc.swingHand(Hand.MAIN_HAND);npc.tryAttack(animal);
            attackCooldown=20;lastAction=npc.age;
        }
        // Actual drops are picked up by SurvivalController. Track only additions to the backpack.
        if(!animal.isAlive()) {animal=null;nextSearch=npc.age+25;}
    }
    /** Called after SurvivalController picks up a legitimate food drop. */
    public void onCollected(ItemStack added) {
        if(kind==Kind.FOOD && foodItem(added))gathered+=added.getCount();
    }
    public void writeNbt(NbtCompound nbt) {
        if(!active())return;
        NbtCompound data=new NbtCompound();
        data.putString("Kind",kind.name());data.putInt("Desired",desired);data.putInt("Gathered",gathered);
        data.putBoolean("Manual",manual);
        if(origin!=null){data.putInt("X",origin.getX());data.putInt("Y",origin.getY());data.putInt("Z",origin.getZ());}
        nbt.put("GatherTask",data);
    }
    public void readNbt(NbtCompound nbt) {
        kind=Kind.NONE;tree=null;animal=null;waypoint=null;waypointIndex=0;idleCooldown=0;
        if(!nbt.contains("GatherTask"))return;
        NbtCompound data=nbt.getCompound("GatherTask");
        try {kind=Kind.valueOf(data.getString("Kind"));}catch(IllegalArgumentException ex){kind=Kind.NONE;}
        desired=Math.max(1,Math.min(264,data.getInt("Desired")));gathered=Math.max(0,data.getInt("Gathered"));
        manual=data.getBoolean("Manual");origin=new BlockPos(data.getInt("X"),data.getInt("Y"),data.getInt("Z"));
        lastAction=npc.age;
    }
}
