package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.nbt.*;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.LinkedHashMap;
import java.util.Map;

/** Real materials, real placed bench, visible work delay, retrieval after use. */
public final class StarterCrafting {
    private final CompanionEntity npc;
    private record Recipe(Item result,int number,Map<Item,Integer> ingredients,boolean bench) {}
    private Recipe pending;
    private BlockPos benchPos;
    private boolean ownBench;
    private int timer;
    private final PhysicalMining mining;
    private boolean reclaiming;
    private int recoveryTicks;

    public StarterCrafting(CompanionEntity npc){this.npc=npc;this.mining=new PhysicalMining(npc);}
    public boolean isWorking(){return pending!=null || reclaiming;}
    private int count(Item item) {
        int total=0;
        for(int i=0;i<npc.backpack.size();i++)if(npc.backpack.getStack(i).isOf(item))total+=npc.backpack.getStack(i).getCount();
        return total;
    }
    private boolean contains(Recipe r){
        for(var ingredient:r.ingredients.entrySet())if(count(ingredient.getKey())<ingredient.getValue())return false;
        return true;
    }
    private boolean use(Item item,int qty) {
        if(count(item)<qty)return false;
        int needed=qty;
        for(int i=0;i<npc.backpack.size() && needed>0;i++){
            ItemStack stack=npc.backpack.getStack(i);
            if(stack.isOf(item)){int n=Math.min(needed,stack.getCount());npc.backpack.removeStack(i,n);needed-=n;}
        }
        return true;
    }
    private boolean produce(Recipe r) {
        if(!contains(r))return false;
        for(var ingredient:r.ingredients.entrySet())use(ingredient.getKey(),ingredient.getValue());
        ItemStack overflow=npc.backpack.addStack(new ItemStack(r.result,r.number));
        if(!overflow.isEmpty())npc.dropStack(overflow);
        npc.backpack.markDirty();
        return true;
    }
    private Item planks() {
        for(Item item:new Item[]{Items.OAK_PLANKS,Items.SPRUCE_PLANKS,Items.BIRCH_PLANKS,Items.JUNGLE_PLANKS,
                Items.ACACIA_PLANKS,Items.DARK_OAK_PLANKS,Items.MANGROVE_PLANKS,Items.CHERRY_PLANKS})if(count(item)>0)return item;
        return null;
    }
    private Recipe planksRecipe(){
        Item[][] variants={{Items.OAK_LOG,Items.OAK_PLANKS},{Items.SPRUCE_LOG,Items.SPRUCE_PLANKS},
            {Items.BIRCH_LOG,Items.BIRCH_PLANKS},{Items.JUNGLE_LOG,Items.JUNGLE_PLANKS},
            {Items.ACACIA_LOG,Items.ACACIA_PLANKS},{Items.DARK_OAK_LOG,Items.DARK_OAK_PLANKS},
            {Items.MANGROVE_LOG,Items.MANGROVE_PLANKS},{Items.CHERRY_LOG,Items.CHERRY_PLANKS}};
        for(Item[] pair:variants)if(count(pair[0])>0)return new Recipe(pair[1],4,Map.of(pair[0],1),false);
        return null;
    }
    private int score(Item it) {
        if(it==Items.NETHERITE_PICKAXE||it==Items.NETHERITE_AXE||it==Items.NETHERITE_SWORD)return 5;
        if(it==Items.DIAMOND_PICKAXE||it==Items.DIAMOND_AXE||it==Items.DIAMOND_SWORD)return 4;
        if(it==Items.IRON_PICKAXE||it==Items.IRON_AXE||it==Items.IRON_SWORD)return 3;
        if(it==Items.STONE_PICKAXE||it==Items.STONE_AXE||it==Items.STONE_SWORD)return 2;
        if(it==Items.WOODEN_PICKAXE||it==Items.WOODEN_AXE||it==Items.WOODEN_SWORD || it==Items.GOLDEN_PICKAXE || it==Items.GOLDEN_AXE || it==Items.GOLDEN_SWORD)return 1;
        return 0;
    }
    private int best(Class<? extends Item> toolType) {
        int best=0;
        ItemStack main=npc.getMainHandStack();
        if(toolType.isInstance(main.getItem()) && (!main.isDamageable() || main.getMaxDamage()-main.getDamage()>4))best=score(main.getItem());
        for(int i=0;i<npc.backpack.size();i++){
            ItemStack s=npc.backpack.getStack(i);
            if(toolType.isInstance(s.getItem()) && (!s.isDamageable() || s.getMaxDamage()-s.getDamage()>4))best=Math.max(best,score(s.getItem()));
        }
        return best;
    }
    private Recipe recipe(Item result,Item material,int count, int sticks) {
        return new Recipe(result,1,Map.of(material,count,Items.STICK,sticks),true);
    }
    private Recipe tryTools(Item material,int level,Item pick,Item axe,Item sword){
        if(count(Items.STICK)<2)return null;
        if(best(PickaxeItem.class)<level && count(material)>=3)return recipe(pick,material,3,2);
        if(best(AxeItem.class)<level && count(material)>=3)return recipe(axe,material,3,2);
        if(best(SwordItem.class)<level && count(material)>=2)return recipe(sword,material,2,1);
        return null;
    }
    private int armorRank(EquipmentSlot slot) {
        int best=armorRankOf(npc.getEquippedStack(slot),slot);
        for(int i=0;i<npc.backpack.size();i++)best=Math.max(best,armorRankOf(npc.backpack.getStack(i),slot));
        return best;
    }
    private int armorRankOf(ItemStack stack,EquipmentSlot slot) {
        if(!(stack.getItem() instanceof ArmorItem armor) || armor.getSlotType()!=slot)return 0;
        ArmorMaterial m=armor.getMaterial();
        if(m==ArmorMaterials.NETHERITE)return 5;
        if(m==ArmorMaterials.DIAMOND)return 4;
        if(m==ArmorMaterials.IRON)return 3;
        if(m==ArmorMaterials.CHAIN || m==ArmorMaterials.GOLD)return 2;
        return 1;
    }
    private Recipe armor(Item material,int level,Item head,Item chest,Item legs,Item feet){
        if(armorRank(EquipmentSlot.CHEST)<level && count(material)>=8)return new Recipe(chest,1,Map.of(material,8),true);
        if(armorRank(EquipmentSlot.LEGS)<level && count(material)>=7)return new Recipe(legs,1,Map.of(material,7),true);
        if(armorRank(EquipmentSlot.HEAD)<level && count(material)>=5)return new Recipe(head,1,Map.of(material,5),true);
        if(armorRank(EquipmentSlot.FEET)<level && count(material)>=4)return new Recipe(feet,1,Map.of(material,4),true);
        return null;
    }
    private Recipe choose() {
        Item plank=planks();
        if(plank==null) {Recipe wood=planksRecipe();if(wood!=null)return wood;}
        // Ensure a reliable wood reserve for bench + sticks before expensive iron recipes.
        if(plank!=null && count(plank)<4) {Recipe wood=planksRecipe();if(wood!=null)return wood;}
        if(plank!=null && count(Items.STICK)<4 && count(plank)>=2)return new Recipe(Items.STICK,4,Map.of(plank,2),false);
        if(plank!=null && count(Items.CRAFTING_TABLE)==0 && locateBench()==null && count(plank)>=4)
            return new Recipe(Items.CRAFTING_TABLE,1,Map.of(plank,4),false);
        Recipe r=tryTools(Items.DIAMOND,4,Items.DIAMOND_PICKAXE,Items.DIAMOND_AXE,Items.DIAMOND_SWORD);
        if(r!=null)return r;
        r=tryTools(Items.IRON_INGOT,3,Items.IRON_PICKAXE,Items.IRON_AXE,Items.IRON_SWORD);
        if(r!=null)return r;
        r=tryTools(Items.COBBLESTONE,2,Items.STONE_PICKAXE,Items.STONE_AXE,Items.STONE_SWORD);
        if(r!=null)return r;
        r=plank==null?null:tryTools(plank,1,Items.WOODEN_PICKAXE,Items.WOODEN_AXE,Items.WOODEN_SWORD);
        if(r!=null)return r;
        r=armor(Items.DIAMOND,4,Items.DIAMOND_HELMET,Items.DIAMOND_CHESTPLATE,Items.DIAMOND_LEGGINGS,Items.DIAMOND_BOOTS);
        if(r!=null)return r;
        return armor(Items.IRON_INGOT,3,Items.IRON_HELMET,Items.IRON_CHESTPLATE,Items.IRON_LEGGINGS,Items.IRON_BOOTS);
    }
    private BlockPos locateBench() {
        BlockPos c=npc.getBlockPos();
        for(BlockPos p:BlockPos.iterate(c.add(-3,-1,-3),c.add(3,2,3)))
            if(npc.getWorld().isChunkLoaded(p) && npc.getWorld().getBlockState(p).isOf(Blocks.CRAFTING_TABLE))return p.toImmutable();
        return null;
    }
    private BlockPos putBench() {
        if(count(Items.CRAFTING_TABLE)<1)return null;
        for(Direction dir:Direction.Type.HORIZONTAL){
            BlockPos p=npc.getBlockPos().offset(dir);
            if(!npc.getWorld().getGameRules().getBoolean(net.minecraft.world.GameRules.DO_MOB_GRIEFING)
                    || !npc.getWorld().getOtherEntities(null,new net.minecraft.util.math.Box(p)).isEmpty()
                    || !npc.getWorld().isChunkLoaded(p) || !npc.getWorld().getBlockState(p).isAir()
                    || !npc.getWorld().getBlockState(p.down()).isSolidBlock(npc.getWorld(),p.down()))continue;
            if(npc.getWorld().setBlockState(p,Blocks.CRAFTING_TABLE.getDefaultState(),3)){
                use(Items.CRAFTING_TABLE,1);ownBench=true;return p.toImmutable();
            }
        }
        return null;
    }
    private void reclaimBench() {
        if(!ownBench || benchPos==null) {reclaiming=false;return;}
        if(!npc.getWorld().isChunkLoaded(benchPos))return;
        if(!npc.getWorld().getBlockState(benchPos).isOf(Blocks.CRAFTING_TABLE)) {
            mining.reset();
            var drops=npc.getWorld().getEntitiesByClass(net.minecraft.entity.ItemEntity.class,
                new net.minecraft.util.math.Box(benchPos).expand(3),d -> d.isAlive()
                    && d.getStack().isOf(Items.CRAFTING_TABLE) && npc.backpack.canInsert(d.getStack()));
            if(npc.autoLoot && !drops.isEmpty() && ++recoveryTicks<100) {
                if(npc.age%10==0)npc.getNavigation().startMovingTo(drops.get(0),1);
                return;
            }
            ownBench=false;benchPos=null;reclaiming=false;recoveryTicks=0;return;
        }
        if(!mining.reachable(benchPos)) {
            if(npc.age%20==0)npc.getNavigation().startMovingTo(benchPos.getX()+0.5,benchPos.getY(),benchPos.getZ()+0.5,1);
            return;
        }
        mining.tick(benchPos);
    }
    public void tick() {
        if(npc.ownerId()==null)return;
        if(npc.menuOpen() || npc.isEating() || npc.getTarget()!=null || npc.isRetreating()){mining.reset();return;}
        if(reclaiming){reclaimBench();return;}
        if(!npc.autoCraft || (npc.gathering().active() && pending==null))return;
        if(pending==null){
            if(npc.age%35!=0)return;
            Recipe r=choose();if(r==null || !contains(r))return;
            if(r.bench){
                benchPos=locateBench();ownBench=false;
                if(benchPos==null)benchPos=putBench();
                if(benchPos==null)return; // No fake 3x3 crafting!
            }
            pending=r; timer=r.bench?34:12;
            npc.getNavigation().stop();return;
        }
        npc.getNavigation().stop();
        if(--timer>0) {
            if(timer%8==0)npc.swingHand(Hand.MAIN_HAND);
            return;
        }
        if(!pending.bench || (benchPos!=null && npc.getWorld().isChunkLoaded(benchPos)
                && npc.getWorld().getBlockState(benchPos).isOf(Blocks.CRAFTING_TABLE)
                && npc.squaredDistanceTo(benchPos.getX()+0.5,benchPos.getY()+0.5,benchPos.getZ()+0.5)<25)){
            produce(pending);
        }
        pending=null;timer=0;reclaiming=ownBench;
    }
    public void writeNbt(NbtCompound root) {
        if(ownBench && benchPos!=null)root.putLong("OwnedBench",benchPos.asLong());
        if(pending==null)return;
        NbtCompound n=new NbtCompound();
        n.putString("Result",Registries.ITEM.getId(pending.result).toString());n.putInt("Output",pending.number);
        n.putBoolean("Bench",pending.bench);n.putBoolean("OwnBench",ownBench);n.putInt("Timer",timer);
        if(benchPos!=null){n.putInt("X",benchPos.getX());n.putInt("Y",benchPos.getY());n.putInt("Z",benchPos.getZ());}
        NbtList ingredients=new NbtList();
        for(var ing:pending.ingredients.entrySet()){
            NbtCompound c=new NbtCompound();c.putString("Item",Registries.ITEM.getId(ing.getKey()).toString());
            c.putInt("Count",ing.getValue());ingredients.add(c);
        }
        n.put("Ingredients",ingredients);root.put("CraftSession",n);
    }
    public void readNbt(NbtCompound root) {
        pending=null;benchPos=null;ownBench=false;timer=0;
        reclaiming=false;
        if(root.contains("OwnedBench")) {benchPos=BlockPos.fromLong(root.getLong("OwnedBench"));ownBench=true;reclaiming=true;}
        if(!root.contains("CraftSession"))return;
        reclaiming=false;
        NbtCompound n=root.getCompound("CraftSession");
        try{
            Item result=Registries.ITEM.get(new Identifier(n.getString("Result")));
            Map<Item,Integer> ingredients=new LinkedHashMap<>();
            NbtList ingredientsNbt=n.getList("Ingredients",NbtElement.COMPOUND_TYPE);
            for(int i=0;i<ingredientsNbt.size();i++){
                NbtCompound c=ingredientsNbt.getCompound(i);
                ingredients.put(Registries.ITEM.get(new Identifier(c.getString("Item"))),c.getInt("Count"));
            }
            pending=new Recipe(result,Math.max(1,n.getInt("Output")),ingredients,n.getBoolean("Bench"));
            ownBench=n.getBoolean("OwnBench");timer=Math.max(1,n.getInt("Timer"));
            if(pending.bench)benchPos=new BlockPos(n.getInt("X"),n.getInt("Y"),n.getInt("Z"));
        }catch(RuntimeException bad){pending=null;ownBench=false;benchPos=null;}
    }
}
