package dev.aiplayer;

import dev.aiplayer.entity.CompanionEntity;
import dev.aiplayer.screen.CompanionMenu;
import dev.aiplayer.mixin.MobGoalsAccess;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.util.ActionResult;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.LivingEntity;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.*;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.screen.ScreenHandlerType;
import net.minecraft.util.Identifier;

public class AIPlayer implements ModInitializer {
    public static final EntityType<CompanionEntity> COMPANION = Registry.register(Registries.ENTITY_TYPE,
        id("companion"), FabricEntityTypeBuilder.create(SpawnGroup.CREATURE, CompanionEntity::new)
        .dimensions(EntityDimensions.fixed(0.6f, 1.8f)).trackRangeBlocks(64).build());
    public static final ScreenHandlerType<CompanionMenu> MENU = Registry.register(Registries.SCREEN_HANDLER,
        id("companion"), new ExtendedScreenHandlerType<>(CompanionMenu::new));
    public static final Item EGG = Registry.register(Registries.ITEM, id("companion_spawn_egg"),
        new SpawnEggItem(COMPANION, 0x32475b, 0x33c7d9, new Item.Settings()));
    public static Identifier id(String path) { return new Identifier("aiplayer", path); }
    @Override public void onInitialize() {
        FabricDefaultAttributeRegistry.register(COMPANION, CompanionEntity.attributes());
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.SPAWN_EGGS).register(e -> e.add(EGG));
        AttackEntityCallback.EVENT.register((player, world, hand, target, hit) -> {
            if (!world.isClient && !player.isSpectator() && target instanceof LivingEntity mob) {
                for (CompanionEntity companion : world.getEntitiesByClass(CompanionEntity.class,
                        player.getBoundingBox().expand(32), c -> c.isAlive() && c.isOwner(player))) {
                    companion.markOwnerAttack(mob);
                }
            }
            return ActionResult.PASS; // Never cancel the player's actual hit.
        });
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            // Neutral mobs keep their vanilla provocation rules.
            if (entity instanceof MobEntity mob
                && (mob instanceof HostileEntity || mob instanceof SlimeEntity)
                && !(mob instanceof EndermanEntity) && !(mob instanceof ZombifiedPiglinEntity)) {
                ((MobGoalsAccess)mob).aiplayer$getTargetSelector().add(3,
                    new ActiveTargetGoal<>(mob, CompanionEntity.class, 10, true, false, c -> c.isAlive()));
            }
        });
    }
}
