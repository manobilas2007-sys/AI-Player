package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.item.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import java.util.Map;

/** Conservative starter recipes. All outputs consume real ingredients. No ore or log is created. */
public final class StarterCrafting {
    private StarterCrafting() {}

    private static int count(CompanionEntity npc, Item item) {
        int n=0;
        for (int i=0;i<npc.backpack.size();i++) {
            ItemStack stack=npc.backpack.getStack(i);
            if (stack.isOf(item)) n+=stack.getCount();
        }
        return n;
    }
    private static int consume(CompanionEntity npc,Item item,int amount) {
        int removed=0;
        for(int i=0;i<npc.backpack.size() && removed<amount;i++) {
            ItemStack stack=npc.backpack.getStack(i);
            if (stack.isOf(item)) {
                int take=Math.min(amount-removed,stack.getCount());
                npc.backpack.removeStack(i,take);removed+=take;
            }
        }
        return removed;
    }
    private static boolean canCraft(CompanionEntity npc,Map<Item,Integer> ingredients) {
        for (var entry:ingredients.entrySet())
            if(count(npc,entry.getKey())<entry.getValue())return false;
        return true;
    }
    private static boolean craft(CompanionEntity npc,Item output,int quantity,Map<Item,Integer> ingredients) {
        if (!canCraft(npc,ingredients)) return false;
        for (var entry:ingredients.entrySet()) consume(npc,entry.getKey(),entry.getValue());
        ItemStack left=npc.backpack.addStack(new ItemStack(output,quantity));
        if (!left.isEmpty()) npc.dropStack(left); // Never silently delete overflow.
        npc.backpack.markDirty();
        return true;
    }
    private static boolean hasTool(CompanionEntity npc,Class<? extends Item> type) {
        if (type.isInstance(npc.getMainHandStack().getItem()))return true;
        for(int i=0;i<npc.backpack.size();i++)if(type.isInstance(npc.backpack.getStack(i).getItem()))return true;
        return false;
    }
    private static boolean woodToPlanks(CompanionEntity npc) {
        Item[][] conversions={
            {Items.OAK_LOG,Items.OAK_PLANKS},{Items.SPRUCE_LOG,Items.SPRUCE_PLANKS},
            {Items.BIRCH_LOG,Items.BIRCH_PLANKS},{Items.JUNGLE_LOG,Items.JUNGLE_PLANKS},
            {Items.ACACIA_LOG,Items.ACACIA_PLANKS},{Items.DARK_OAK_LOG,Items.DARK_OAK_PLANKS},
            {Items.MANGROVE_LOG,Items.MANGROVE_PLANKS},{Items.CHERRY_LOG,Items.CHERRY_PLANKS}
        };
        for(Item[] pair:conversions) if(count(npc,pair[0])>0) {
            return craft(npc,pair[1],4,Map.of(pair[0],1));
        }
        return false;
    }
    private static Item findPlanks(CompanionEntity npc) {
        for(Item it:new Item[]{Items.OAK_PLANKS,Items.SPRUCE_PLANKS,Items.BIRCH_PLANKS,
                Items.JUNGLE_PLANKS,Items.ACACIA_PLANKS,Items.DARK_OAK_PLANKS,
                Items.MANGROVE_PLANKS,Items.CHERRY_PLANKS}) {
            if(count(npc,it)>=2)return it;
        }
        return null;
    }

    private static boolean nearTable(CompanionEntity npc) {
        BlockPos center=npc.getBlockPos();
        for(BlockPos p:BlockPos.iterate(center.add(-3,-1,-3),center.add(3,2,3)))
            if(npc.getWorld().isChunkLoaded(p) && npc.getWorld().getBlockState(p).isOf(Blocks.CRAFTING_TABLE))return true;
        return false;
    }
    /** A temporary workbench is placed only in an unoccupied, safe adjacent position. */
    private static BlockPos placeOwnTable(CompanionEntity npc) {
        if(count(npc,Items.CRAFTING_TABLE)==0)return null;
        for(Direction d:Direction.Type.HORIZONTAL) {
            BlockPos p=npc.getBlockPos().offset(d);
            if(!npc.getWorld().getBlockState(p).isAir()
                || !npc.getWorld().getBlockState(p.down()).isSolidBlock(npc.getWorld(),p.down()))continue;
            if(npc.getWorld().setBlockState(p,Blocks.CRAFTING_TABLE.getDefaultState(),3)) {
                consume(npc,Items.CRAFTING_TABLE,1);
                return p;
            }
        }
        return null;
    }
    private static void recoverOwnTable(CompanionEntity npc,BlockPos p) {
        if (p == null || !npc.getWorld().getBlockState(p).isOf(Blocks.CRAFTING_TABLE)) return;
        if(npc.getWorld().setBlockState(p,Blocks.AIR.getDefaultState(),3)) {
            ItemStack left=npc.backpack.addStack(new ItemStack(Items.CRAFTING_TABLE));
            if(!left.isEmpty())npc.dropStack(left);
        }
    }
    private static boolean atWorkbench(CompanionEntity npc,Item result,Map<Item,Integer> ingredients) {
        if(!canCraft(npc,ingredients))return false;
        BlockPos own=null;
        if(!nearTable(npc))own=placeOwnTable(npc);
        if(own==null && !nearTable(npc))return false;
        try {return craft(npc,result,1,ingredients);} finally {recoverOwnTable(npc,own);}
    }

    private static boolean hasArmor(CompanionEntity npc,EquipmentSlot slot) {
        if(!npc.getEquippedStack(slot).isEmpty())return true;
        for(int i=0;i<npc.backpack.size();i++) {
            ItemStack stack=npc.backpack.getStack(i);
            if(stack.getItem() instanceof ArmorItem armor && armor.getSlotType()==slot)return true;
        }
        return false;
    }
    private static boolean craftStarterArmor(CompanionEntity npc) {
        if(!hasArmor(npc,EquipmentSlot.CHEST)) {
            if(count(npc,Items.DIAMOND)>=8 && atWorkbench(npc,Items.DIAMOND_CHESTPLATE,Map.of(Items.DIAMOND,8)))return true;
            if(count(npc,Items.IRON_INGOT)>=8 && atWorkbench(npc,Items.IRON_CHESTPLATE,Map.of(Items.IRON_INGOT,8)))return true;
        }
        if(!hasArmor(npc,EquipmentSlot.HEAD)) {
            if(count(npc,Items.DIAMOND)>=5 && atWorkbench(npc,Items.DIAMOND_HELMET,Map.of(Items.DIAMOND,5)))return true;
            if(count(npc,Items.IRON_INGOT)>=5 && atWorkbench(npc,Items.IRON_HELMET,Map.of(Items.IRON_INGOT,5)))return true;
        }
        if(!hasArmor(npc,EquipmentSlot.LEGS)) {
            if(count(npc,Items.DIAMOND)>=7 && atWorkbench(npc,Items.DIAMOND_LEGGINGS,Map.of(Items.DIAMOND,7)))return true;
            if(count(npc,Items.IRON_INGOT)>=7 && atWorkbench(npc,Items.IRON_LEGGINGS,Map.of(Items.IRON_INGOT,7)))return true;
        }
        if(!hasArmor(npc,EquipmentSlot.FEET)) {
            if(count(npc,Items.DIAMOND)>=4 && atWorkbench(npc,Items.DIAMOND_BOOTS,Map.of(Items.DIAMOND,4)))return true;
            if(count(npc,Items.IRON_INGOT)>=4 && atWorkbench(npc,Items.IRON_BOOTS,Map.of(Items.IRON_INGOT,4)))return true;
        }
        return false;
    }
    /** Called at a low frequency and only when no combat or GUI interaction is active. */
    public static void tick(CompanionEntity npc) {
        if(npc.menuOpen() || npc.isEating() || npc.getTarget()!=null || npc.isRetreating())return;
        if(craftStarterArmor(npc))return;
        Item plank=findPlanks(npc);
        if(plank==null && woodToPlanks(npc))return;
        if(plank==null)return;
        // Do not strand a few planks when more logs are available for a workbench.
        if(count(npc,plank)<4 && woodToPlanks(npc))return;
        if(count(npc,Items.STICK)<2 && craft(npc,Items.STICK,4,Map.of(plank,2)))return;
        if(count(npc,Items.CRAFTING_TABLE)==0 && !nearTable(npc) && count(npc,plank)>=4) {
            if(craft(npc,Items.CRAFTING_TABLE,1,Map.of(plank,4)))return;
        }
        if(count(npc,Items.STICK)<2)return;
        if(!hasTool(npc,PickaxeItem.class)) {
            if(count(npc,Items.IRON_INGOT)>=3 && atWorkbench(npc,Items.IRON_PICKAXE,Map.of(Items.IRON_INGOT,3,Items.STICK,2)))return;
            if(count(npc,Items.COBBLESTONE)>=3 && atWorkbench(npc,Items.STONE_PICKAXE,Map.of(Items.COBBLESTONE,3,Items.STICK,2)))return;
            if(count(npc,plank)>=3 && atWorkbench(npc,Items.WOODEN_PICKAXE,Map.of(plank,3,Items.STICK,2)))return;
        }
        if(!hasTool(npc,AxeItem.class)) {
            if(count(npc,Items.IRON_INGOT)>=3 && atWorkbench(npc,Items.IRON_AXE,Map.of(Items.IRON_INGOT,3,Items.STICK,2)))return;
            if(count(npc,Items.COBBLESTONE)>=3 && atWorkbench(npc,Items.STONE_AXE,Map.of(Items.COBBLESTONE,3,Items.STICK,2)))return;
            if(count(npc,plank)>=3 && atWorkbench(npc,Items.WOODEN_AXE,Map.of(plank,3,Items.STICK,2)))return;
        }
        if(!hasTool(npc,SwordItem.class)) {
            if(count(npc,Items.IRON_INGOT)>=2 && atWorkbench(npc,Items.IRON_SWORD,Map.of(Items.IRON_INGOT,2,Items.STICK,1)))return;
            if(count(npc,Items.COBBLESTONE)>=2 && atWorkbench(npc,Items.STONE_SWORD,Map.of(Items.COBBLESTONE,2,Items.STICK,1)))return;
            if(count(npc,plank)>=2)atWorkbench(npc,Items.WOODEN_SWORD,Map.of(plank,2,Items.STICK,1));
        }
    }
}
