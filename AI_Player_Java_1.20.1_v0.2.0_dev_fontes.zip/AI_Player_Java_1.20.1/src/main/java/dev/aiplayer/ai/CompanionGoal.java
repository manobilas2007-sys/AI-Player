package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.entity.*;
import net.minecraft.entity.ai.goal.Goal;
import net.minecraft.entity.ai.NoPenaltyTargeting;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.block.Blocks;
import net.minecraft.util.Hand;
import net.minecraft.util.math.*;
import java.util.*;

/** One movement owner, with threat -> flee/eat -> loot -> follow priorities. */
public class CompanionGoal extends Goal {
    private final CompanionEntity npc;
    private int nextPath, nextScan, attackCooldown, stuckTicks;
    private Vec3d previous = Vec3d.ZERO;
    private boolean following;
    public CompanionGoal(CompanionEntity npc) {
        this.npc = npc;
        setControls(EnumSet.of(Control.MOVE,Control.LOOK,Control.JUMP));
    }
    @Override public boolean canStart() { return npc.ownerId() != null; }
    @Override public boolean shouldContinue() { return canStart(); }
    @Override public boolean shouldRunEveryTick() { return true; }

    private boolean enemy(LivingEntity e) {
        return e != null && e.isAlive() && npc.canTarget(e) && npc.squaredDistanceTo(e) < 24 * 24;
    }
    public static boolean isNaturallyHostile(LivingEntity e) {
        // Slimes/magma cubes are Monster mobs but do not inherit HostileEntity.
        return (e instanceof HostileEntity || e instanceof SlimeEntity)
            && !(e instanceof EndermanEntity) && !(e instanceof ZombifiedPiglinEntity);
    }

    @Override public void tick() {
        if (attackCooldown > 0) attackCooldown--;
        if (nextPath > 0) nextPath--;
        PlayerEntity owner = npc.owner();

        if (--nextScan <= 0) {
            nextScan = 5;
            LivingEntity current = npc.getTarget();
            if (!enemy(current)) npc.setTarget(null);
            LivingEntity attacker = npc.getAttacker();
            LivingEntity ownerAttacker = owner == null ? null : owner.getAttacker();
            LivingEntity ownerVictim = owner == null ? null : owner.getAttacking();

            // Highest priority: defend ourselves and owner, even against a normally neutral mob.
            if (enemy(attacker) && npc.age - npc.getLastAttackedTime() < 200) npc.setTarget(attacker);
            else if (enemy(ownerAttacker) && owner != null && owner.age - owner.getLastAttackedTime() < 200) npc.setTarget(ownerAttacker);
            else if (enemy(ownerVictim) && owner != null && owner.age - owner.getLastAttackTime() < 200) npc.setTarget(ownerVictim);
            else if (enemy(npc.getOwnerMarkedTarget())) npc.setTarget(npc.getOwnerMarkedTarget());
            else if (npc.mode() == Mode.GUARD && npc.getTarget() == null) {
                npc.getWorld().getEntitiesByClass(MobEntity.class,npc.getBoundingBox().expand(12),
                    e -> isNaturallyHostile(e) && enemy(e) && npc.canSee(e))
                    .stream().min(Comparator.comparingDouble(npc::squaredDistanceTo)).ifPresent(npc::setTarget);
            }
        }

        LivingEntity target = npc.getTarget();
        if (!enemy(target)) { npc.setTarget(null); target = null; }
        boolean danger = target != null;
        boolean low = npc.getHealth() <= 10;
        if (low) npc.setRetreating(true);
        if (npc.isRetreating() && npc.getHealth() >= 19 && !danger) npc.setRetreating(false);

        if (npc.isEating() && danger && npc.squaredDistanceTo(target) < 100) npc.cancelEating();
        if (npc.isRetreating()) {
            if (npc.isEating()) return;
            if (target != null && nextPath == 0) {
                Vec3d away = NoPenaltyTargeting.findFrom(npc,12,5,target.getPos());
                if (away != null) npc.getNavigation().startMovingTo(away.x,away.y,away.z,1.35);
                nextPath=15;
            } else if (target == null && owner != null && npc.squaredDistanceTo(owner)>100 && nextPath==0) {
                npc.getNavigation().startMovingTo(owner,1.2);
                nextPath=20;
            }
            return; // Do not go straight back into battle while critically injured.
        }
        if (npc.isEating()) {
            if (danger && npc.squaredDistanceTo(target) < 64) npc.cancelEating();
            else { npc.getNavigation().stop(); return; }
        }
        if (danger) {
            npc.getLookControl().lookAt(target,30,30);
            if (nextPath == 0) { npc.getNavigation().startMovingTo(target,1.15);nextPath=10; }
            if (npc.squaredDistanceTo(target)<2.5*2.5 && npc.canSee(target) && attackCooldown==0) {
                npc.swingHand(Hand.MAIN_HAND);
                npc.tryAttack(target);
                attackCooldown=npc.getMainHandStack().getItem() instanceof net.minecraft.item.AxeItem?25:20;
            }
            return;
        }
        if (npc.menuOpen() || npc.mode() == Mode.WAIT || owner == null || owner.isSpectator()) {
            npc.getNavigation().stop(); following=false; return;
        }
        double distance = npc.squaredDistanceTo(owner);
        if (distance > 225) following=true;
        if (distance < 64) following=false;
        if (nextPath > 0) return;
        nextPath=20;
        if (following) {
            if (npc.getPos().squaredDistanceTo(previous)<0.25) stuckTicks+=20;
            else stuckTicks=0;
            previous=npc.getPos();
            if (distance>1024 || stuckTicks>=100) {
                if (recall(npc,owner)) {stuckTicks=0;following=false;return;}
            }
            npc.getNavigation().startMovingTo(owner,1.2);
        } else {
            // Loose items are useful but never interrupt protection or following a distant owner.
            if (npc.autoLoot && npc.getNavigation().isIdle()) {
                var drops=npc.getWorld().getEntitiesByClass(ItemEntity.class,npc.getBoundingBox().expand(9),
                    d -> d.isAlive() && !d.getStack().isEmpty() && npc.backpack.canInsert(d.getStack()));
                if (!drops.isEmpty()) {
                    ItemEntity closest = drops.stream().min(Comparator.comparingDouble(npc::squaredDistanceTo)).orElse(null);
                    if (closest!=null && closest.squaredDistanceTo(owner)<225 && npc.squaredDistanceTo(closest)>3) {
                        npc.getNavigation().startMovingTo(closest,1.0);
                        return;
                    }
                }
            }
            if (npc.getNavigation().isIdle() && npc.getRandom().nextInt(5)==0) {
                Vec3d point=NoPenaltyTargeting.find(npc,7,3);
                if(point!=null && point.squaredDistanceTo(owner.getPos())<225)
                    npc.getNavigation().startMovingTo(point.x,point.y,point.z,0.85);
            }
        }
    }

    public static boolean recall(CompanionEntity npc,PlayerEntity owner) {
        if(npc.getWorld()!=owner.getWorld())return false;
        BlockPos base=owner.getBlockPos();
        for(int radius=2;radius<=4;radius++)for(int dx=-radius;dx<=radius;dx++)for(int dz=-radius;dz<=radius;dz++) {
            if(Math.max(Math.abs(dx),Math.abs(dz))!=radius)continue;
            for(int dy : new int[]{0,1,-1,2,-2}) {
                BlockPos p=base.add(dx,dy,dz);
                if(!npc.getWorld().isChunkLoaded(p))continue;
                var floor=npc.getWorld().getBlockState(p.down());
                if(!floor.isSolidBlock(npc.getWorld(),p.down()) || floor.isOf(Blocks.MAGMA_BLOCK)
                    ||floor.isOf(Blocks.CACTUS)||floor.isOf(Blocks.CAMPFIRE)||floor.isOf(Blocks.SOUL_CAMPFIRE))continue;
                if(!npc.getWorld().getFluidState(p).isEmpty()||!npc.getWorld().getFluidState(p.up()).isEmpty())continue;
                if(!npc.getWorld().getBlockState(p).isAir()||!npc.getWorld().getBlockState(p.up()).isAir())continue;
                Vec3d to=Vec3d.ofBottomCenter(p);
                Box box=npc.getBoundingBox().offset(to.subtract(npc.getPos()));
                if(!npc.getWorld().isSpaceEmpty(npc,box))continue;
                npc.getNavigation().stop();npc.refreshPositionAndAngles(to.x,to.y,to.z,npc.getYaw(),npc.getPitch());
                npc.setVelocity(Vec3d.ZERO);npc.fallDistance=0;return true;
            }
        }
        return false;
    }
    @Override public void stop() { npc.getNavigation().stop(); npc.setTarget(null); }
}
