package dev.aiplayer.test;
import dev.aiplayer.AIPlayer;
import dev.aiplayer.ai.*;
import dev.aiplayer.ai.brain.ResourcePlan;
import dev.aiplayer.entity.CompanionEntity;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
import net.minecraft.entity.*;
import net.minecraft.item.*;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.math.*;
import net.minecraft.block.Blocks;
import net.minecraft.enchantment.Enchantments;
import java.util.UUID;

public class SurfaceMiningTests implements FabricGameTest {
    private CompanionEntity worker(TestContext c){
        for(int x=0;x<9;x++)for(int z=0;z<9;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.DIRT);
        CompanionEntity a=c.spawnEntity(AIPlayer.COMPANION,new BlockPos(2,2,2));
        NbtCompound n=new NbtCompound();a.writeCustomDataToNbt(n);n.putUuid("Owner",UUID.randomUUID());a.readCustomDataFromNbt(n);
        a.autoCraft=false;a.autoSurvive=false;return a;
    }
    private boolean owns(CompanionEntity a,Item item){return a.getMainHandStack().isOf(item)||a.backpack.count(item)>0;}
    private String debug(CompanionEntity a){return " pos="+a.getPos()+" hand="+a.getMainHandStack()+" status="+a.intelligence().status()+" bag="+java.util.stream.IntStream.range(0,a.backpack.size()).mapToObj(i->a.backpack.getStack(i).toString()).toList();}
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=500)
    public void physicalOrderStopsAfterThreePickups(TestContext c){
        CompanionEntity a=worker(c);a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_PICKAXE));
        for(int z=1;z<=3;z++)c.setBlockState(new BlockPos(4,2,z),Blocks.STONE);
        a.gathering().start(ResourceGathering.Kind.STONE,3,true);
        c.runAtTick(450,()->{
            c.assertTrue(!a.gathering().active() && a.backpack.count(Items.COBBLESTONE)==3,"Physical collection incomplete"+debug(a));
            c.assertTrue(a.getMainHandStack().getDamage()==3,"Wrong durability for three stone blocks");c.complete();
        });
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=90)
    public void refusesStoneWithoutPick(TestContext c){
        CompanionEntity a=worker(c);c.setBlockState(new BlockPos(4,2,2),Blocks.STONE);a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(70,()->{c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(4,2,2))).isOf(Blocks.STONE),"Destroyed stone without a pick");c.assertTrue(a.backpack.count(Items.COBBLESTONE)==0 && !a.gathering().active(),"Invalid collection result");c.complete();});
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=250)
    public void worldDropBeforeInventory(TestContext c){
        CompanionEntity a=worker(c);a.autoLoot=false;a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_PICKAXE));
        BlockPos p=c.getAbsolutePos(new BlockPos(4,2,2));c.getWorld().setBlockState(p,Blocks.STONE.getDefaultState());
        var stone=new SurfaceStoneGathering(a);
        for(int t=5;t<170;t++)c.runAtTick(t,stone::tick);
        c.runAtTick(180,()->{
            c.assertTrue(c.getWorld().getBlockState(p).isAir(),"No physical break "+stone.diagnostics(p));
            c.assertTrue(a.backpack.count(Items.COBBLESTONE)==0,"Remote insertion");
            int count=c.getWorld().getEntitiesByClass(ItemEntity.class,new Box(p).expand(3),e->e.getStack().isOf(Items.COBBLESTONE)).stream().mapToInt(e->e.getStack().getCount()).sum();
            c.assertTrue(count==1,"Drop duplicated/lost: "+count);c.complete();
        });
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface")
    public void rejectsProtectedSupportFluidAndGravity(TestContext c){
        CompanionEntity a=worker(c);var stone=new SurfaceStoneGathering(a);BlockPos p=c.getAbsolutePos(new BlockPos(4,2,2));c.getWorld().setBlockState(p,Blocks.STONE.getDefaultState());
        c.assertTrue(stone.safeBlock(p),"Unobstructed stone rejected");OwnedBlocks.get(c.getWorld()).playerPlaced(c.getWorld(),p);
        c.assertFalse(stone.safeBlock(p),"Protected construction accepted");OwnedBlocks.get(c.getWorld()).playerBroke(p);
        c.getWorld().setBlockState(p.east(),Blocks.WATER.getDefaultState());c.assertFalse(stone.safeBlock(p),"Fluid pocket accepted");c.getWorld().setBlockState(p.east(),Blocks.AIR.getDefaultState());
        c.getWorld().setBlockState(p.up(),Blocks.SAND.getDefaultState());c.assertFalse(stone.safeBlock(p),"Falling sand accepted");c.getWorld().setBlockState(p.up(),Blocks.AIR.getDefaultState());
        BlockPos floor=a.getBlockPos().down();c.getWorld().setBlockState(floor,Blocks.STONE.getDefaultState());c.assertFalse(stone.safeBlock(floor),"NPC support accepted");c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=450)
    public void usesNonSilkPick(TestContext c){
        CompanionEntity a=worker(c);ItemStack silk=new ItemStack(Items.DIAMOND_PICKAXE);silk.addEnchantment(Enchantments.SILK_TOUCH,1);
        a.equipStack(EquipmentSlot.MAINHAND,silk);a.backpack.setStack(0,new ItemStack(Items.WOODEN_PICKAXE));
        BlockPos p=new BlockPos(4,2,2);c.setBlockState(p,Blocks.STONE);a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(400,()->{c.assertTrue(a.backpack.count(Items.COBBLESTONE)==1,"Silk tool selection failed"+debug(a)+new SurfaceStoneGathering(a).diagnostics(c.getAbsolutePos(p)));c.assertTrue(silk.getDamage()==0,"Used silk tool");c.complete();});
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=900)
    public void makesPickAndResumesManualOrder(TestContext c){
        CompanionEntity a=worker(c);a.autoCraft=true;a.setMode(Mode.WAIT);
        a.backpack.setStack(0,new ItemStack(Items.OAK_LOG,6));a.backpack.setStack(1,new ItemStack(Items.WOODEN_AXE));a.backpack.setStack(2,new ItemStack(Items.WOODEN_SWORD));
        BlockPos p=new BlockPos(4,2,2);c.setBlockState(p,Blocks.STONE);a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(850,()->{c.assertTrue(owns(a,Items.WOODEN_PICKAXE) && a.backpack.count(Items.COBBLESTONE)==1 && !a.gathering().active(),"Prerequisite sequence failed"+debug(a)+new SurfaceStoneGathering(a).diagnostics(c.getAbsolutePos(p)));c.complete();});
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface")
    public void savesAndCancelsMaterialSubgoal(TestContext c){
        CompanionEntity a=worker(c);a.autoCraft=true;a.setMode(Mode.WAIT);a.gathering().start(ResourceGathering.Kind.STONE,16,true);a.intelligence().tick();
        NbtCompound n=new NbtCompound();a.writeCustomDataToNbt(n);
        c.assertTrue(a.gathering().kind()==ResourceGathering.Kind.WOOD && a.gathering().isManual(),"Lost permission for manual WAIT prerequisite");
        c.assertTrue(n.getCompound("MaterialGatherJob").getCompound("GatherTask").getInt("Desired")==16,"Lost parent quantity");
        CompanionEntity b=AIPlayer.COMPANION.create(c.getWorld());b.readCustomDataFromNbt(n);b.gathering().cancel();NbtCompound out=new NbtCompound();b.writeCustomDataToNbt(out);
        c.assertFalse(out.contains("MaterialGatherJob"),"Cancelled job can resurrect");c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=1500)
    public void autonomousThreeStoneTools(TestContext c){
        CompanionEntity a=worker(c);a.autoCraft=true;var owner=c.createMockCreativeServerPlayerInWorld();Vec3d p=Vec3d.ofBottomCenter(c.getAbsolutePos(new BlockPos(1,2,1)));owner.refreshPositionAndAngles(p.x,p.y,p.z,0,0);
        NbtCompound n=new NbtCompound();a.writeCustomDataToNbt(n);n.putUuid("Owner",owner.getUuid());a.readCustomDataFromNbt(n);
        Item[] items={Items.OAK_LOG,Items.OAK_PLANKS,Items.STICK,Items.CRAFTING_TABLE,Items.WOODEN_PICKAXE,Items.WOODEN_AXE,Items.WOODEN_SWORD};int[] counts={4,8,8,1,1,1,1};
        for(int i=0;i<items.length;i++)a.backpack.setStack(i,new ItemStack(items[i],counts[i]));
        for(int z=0;z<8;z++)c.setBlockState(new BlockPos(5,2,z),Blocks.STONE);
        c.runAtTick(1400,()->{c.assertTrue(owns(a,Items.STONE_PICKAXE)&&owns(a,Items.STONE_AXE)&&owns(a,Items.STONE_SWORD),"Autonomous upgrade failed"+debug(a));c.assertTrue(ResourcePlan.stoneNeeded(a)==0 && a.backpack.count(Items.COBBLESTONE)==0,"Wrong material accounting");owner.discard();c.complete();});
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=500)
    public void avoidsCoveredStone(TestContext c){
        CompanionEntity a=worker(c);a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_PICKAXE));c.setBlockState(new BlockPos(4,2,2),Blocks.STONE);
        for(int x=3;x<=5;x++)for(int z=1;z<=3;z++)c.setBlockState(new BlockPos(x,5,z),Blocks.OAK_PLANKS);
        a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(450,()->{c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(4,2,2))).isOf(Blocks.STONE),"Entered cave mining");c.complete();});
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=160)
    public void detectsStoneThirtyBlocksAway(TestContext c){
        CompanionEntity a=worker(c);a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_PICKAXE));
        // Preserve the full 32-block search distance, but give the pathfinder a
        // properly supported corridor instead of a 5-wide platform ending in void.
        // This changes the artificial arena, not the reachability assertion.
        for(int x=0;x<36;x++)for(int z=0;z<13;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.DIRT);
        BlockPos p=new BlockPos(32,2,2);c.setBlockState(p,Blocks.STONE);a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(130,()->{c.assertTrue(a.getY()>=1.9,"Fell from long-distance mining corridor"+debug(a));
            c.assertTrue(a.intelligence().memory().nearest("surface_stone",c.getAbsolutePos(p),c.getWorld().getTime(),1).isPresent(),"Missed distant stone"+debug(a));c.complete();});
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface")
    public void refusesThinExposedBridgeForMining(TestContext c){
        CompanionEntity a=worker(c);
        // A one-block-wide approach beside two deep drops is not a safe work route.
        BlockPos feet=c.getAbsolutePos(new BlockPos(12,2,2));
        for(int x=10;x<=14;x++){
            c.setBlockState(new BlockPos(x,1,2),Blocks.DIRT);
            for(int z=1;z<=3;z++)if(z!=2)for(int y=-1;y<=1;y++)c.setBlockState(new BlockPos(x,y,z),Blocks.AIR);
        }
        c.assertFalse(WorkNavigation.safeWorkFooting(a,feet),"Unsafe bridge accepted as stable mining footing");
        c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="surface",tickLimit=2400)
    public void emptyInventoryWoodThenStone(TestContext c){
        CompanionEntity a=worker(c);a.autoCraft=true;a.setMode(Mode.WAIT);
        for(BlockPos base:java.util.List.of(new BlockPos(4,2,2),new BlockPos(4,2,6),new BlockPos(7,2,6))){for(int y=0;y<3;y++)c.setBlockState(base.up(y),Blocks.OAK_LOG);c.setBlockState(base.up(3),Blocks.OAK_LEAVES);}
        BlockPos p=new BlockPos(7,2,3);c.setBlockState(p,Blocks.STONE);a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(2200,()->{c.assertTrue(a.backpack.count(Items.COBBLESTONE)==1 && owns(a,Items.WOODEN_PICKAXE) && !a.gathering().active(),"Full sequence failed"+debug(a)+new SurfaceStoneGathering(a).diagnostics(c.getAbsolutePos(p)));c.complete();});
    }
}
