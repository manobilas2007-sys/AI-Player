package dev.aiplayer.test;

import dev.aiplayer.AIPlayer;
import dev.aiplayer.ai.*;
import dev.aiplayer.entity.CompanionEntity;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.*;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.*;
import net.minecraft.util.math.*;
import java.util.UUID;

/** Regression cases added after the real-world ice forest/cave report, not replacements for existing tests. */
public final class WorldRegressionTests implements FabricGameTest {
    private CompanionEntity worker(TestContext c){
        for(int x=0;x<9;x++)for(int z=0;z<9;z++)c.setBlockState(new BlockPos(x,1,z),Blocks.DIRT);
        CompanionEntity npc=c.spawnEntity(AIPlayer.COMPANION,new BlockPos(2,2,2));
        NbtCompound n=new NbtCompound();npc.writeCustomDataToNbt(n);n.putUuid("Owner",UUID.randomUUID());npc.readCustomDataFromNbt(n);
        npc.autoCraft=false;npc.autoSurvive=false;return npc;
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="world_regression",tickLimit=600)
    public void stoneCanBeMinedInsideCoveredSafeChamber(TestContext c){
        CompanionEntity a=worker(c);
        a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_PICKAXE));
        for(int x=0;x<8;x++)for(int z=0;z<8;z++)c.setBlockState(new BlockPos(x,6,z),Blocks.STONE);
        c.setBlockState(new BlockPos(4,2,2),Blocks.STONE);
        a.gathering().start(ResourceGathering.Kind.STONE,1,true);
        c.runAtTick(500,()->{
            c.assertTrue(a.backpack.count(Items.COBBLESTONE)==1 && !a.gathering().active(),
                "Accessible chamber stone not acquired. " + a.intelligence().status());
            c.complete();
        });
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="world_regression",tickLimit=130)
    public void submergedDropAcceptsShortSwimRoute(TestContext c){
        CompanionEntity a=worker(c);
        BlockPos target=new BlockPos(4,2,2);
        c.setBlockState(new BlockPos(3,2,2),Blocks.WATER);
        c.setBlockState(target,Blocks.WATER);
        BlockPos abs=c.getAbsolutePos(target);
        ItemEntity drop=new ItemEntity(c.getWorld(),abs.getX()+0.5,abs.getY()+0.3,abs.getZ()+0.5,new ItemStack(Items.SPRUCE_LOG,1));
        drop.setPickupDelay(0);c.getWorld().spawnEntity(drop);
        a.refreshPositionAndAngles(c.getAbsolutePos(new BlockPos(3,2,2)).getX()+0.5,
            c.getAbsolutePos(new BlockPos(3,2,2)).getY()+0.2,
            c.getAbsolutePos(new BlockPos(3,2,2)).getZ()+0.5,0,0);
        c.runAtTick(10,()->{
            c.assertTrue(WorkNavigation.swimToDrop(a,drop) || a.backpack.count(Items.SPRUCE_LOG)>0,
                "Nearby water drop route refused while swimming");
            c.complete();
        });
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="world_regression",tickLimit=20)
    public void blockedPickupDoesNotClaimContact(TestContext c){
        CompanionEntity a=worker(c);
        BlockPos dropPos=new BlockPos(4,2,2);
        BlockPos abs=c.getAbsolutePos(dropPos);
        c.setBlockState(new BlockPos(3,2,2),Blocks.STONE);
        c.setBlockState(new BlockPos(3,3,2),Blocks.STONE);
        // The item is close enough for pickup but genuinely behind a 2-block wall.
        ItemEntity drop=new ItemEntity(c.getWorld(),abs.getX()+0.05,abs.getY()+0.5,abs.getZ()+0.5,new ItemStack(Items.OAK_LOG));
        drop.setPickupDelay(0);c.getWorld().spawnEntity(drop);
        c.assertFalse(a.survival().canCollect(drop),"Drop behind wall incorrectly considered collectible");
        c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="world_regression",tickLimit=130)
    public void isolatedSupportCleanupDefersInsteadOfFreezingWood(TestContext c){
        CompanionEntity a=worker(c);
        a.setAiDisabled(true);
        BlockPos support=new BlockPos(2,1,2);
        for(int x=0;x<6;x++)for(int z=0;z<6;z++)
            if(x!=2 || z!=2)c.setBlockState(new BlockPos(x,1,z),Blocks.AIR);
        c.setBlockState(support,Blocks.COBBLESTONE);
        OwnedBlocks.get(c.getWorld()).claim(c.getAbsolutePos(support),a.getUuid());
        a.gathering().start(ResourceGathering.Kind.WOOD,8,true);
        NbtCompound saved=new NbtCompound();a.gathering().writeNbt(saved);
        NbtList list=new NbtList();NbtCompound block=new NbtCompound();
        block.putLong("Pos",c.getAbsolutePos(support).asLong());block.putString("Block","minecraft:cobblestone");
        list.add(block);saved.put("TemporaryPillar",list);a.gathering().readNbt(saved);
        c.runAtTick(95,()->{
            c.assertTrue(a.gathering().active() && !a.gathering().hasCleanup(),
                "An unreachable temporary pillar permanently blocks gathering");
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(support)).isOf(Blocks.COBBLESTONE),
                "Cleanup mined the block under the NPC");
            c.complete();
        });
    }

    @GameTest(templateName="aiplayer_test:surface_arena",batchId="world_regression",tickLimit=20)
    public void lostBenchRemainsRecordedForRecovery(TestContext c){
        CompanionEntity a=worker(c);
        BlockPos remote=c.getAbsolutePos(new BlockPos(7,2,7));
        c.getWorld().setBlockState(remote,Blocks.CRAFTING_TABLE.getDefaultState());
        NbtCompound state=new NbtCompound();
        state.putLongArray("DeferredOwnedBenches",new long[]{remote.asLong()});
        a.crafting().readNbt(state);
        NbtCompound persisted=new NbtCompound();a.crafting().writeNbt(persisted);
        c.assertTrue(persisted.getLongArray("DeferredOwnedBenches").length==1
            && persisted.getLongArray("DeferredOwnedBenches")[0]==remote.asLong(),
            "Recovery memory lost bench ownership after reload");
        c.complete();
    }
}
