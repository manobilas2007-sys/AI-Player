package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.passive.AnimalEntity;
import net.minecraft.entity.passive.CowEntity;
import net.minecraft.entity.passive.PigEntity;
import net.minecraft.entity.passive.SheepEntity;
import net.minecraft.entity.passive.RabbitEntity;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import java.util.Comparator;
import java.util.List;

/**
 * Limited, chunk-safe resource tasks. Only loaded trees and non-owned farm animals are targets.
 * Combat/retreat/eating always preempt this controller in CompanionGoal.
 */
public final class ResourceGathering {
    public enum Kind { NONE, WOOD, FOOD, STONE }
    private final CompanionEntity npc;
    private Kind kind=Kind.NONE, lastAutoKind=Kind.NONE;
    private int desired, gathered, lastAction, nextSearch, noProgressTicks, idleCooldown;
    private boolean manual;
    private BlockPos origin, tree;
    private AnimalEntity animal;
    private BlockPos waypoint;
    private int waypointIndex, waypointStarted, huntStarted;
    private final java.util.Map<java.util.UUID,Integer> avoidedAnimals=new java.util.HashMap<>();
    private Vec3d lastLocation=Vec3d.ZERO;
    private int attackCooldown, pausedAt=-1;
    private final PhysicalMining mining;
    private final SurfaceStoneGathering stone;
    private final TemporaryPillar pillar;
    private final java.util.List<BlockPos> treeLogs = new java.util.ArrayList<>();
    private boolean cleaning;
    private net.minecraft.entity.ItemEntity lootTarget;
    private int lootStarted, nextAutoCheck, nextRoute, nextDropScan;
    private final java.util.Map<java.util.UUID,Integer> avoidedDrops=new java.util.HashMap<>();
    private record DeferredTree(BlockPos base,java.util.List<BlockPos> logs,long retry,long expires) {}
    private final java.util.List<DeferredTree> deferredTrees=new java.util.ArrayList<>();
    private final java.util.Map<BlockPos,Integer> avoidedTrees = new java.util.HashMap<>();

    public ResourceGathering(CompanionEntity npc) {this.npc=npc;mining=new PhysicalMining(npc);stone=new SurfaceStoneGathering(npc);pillar=new TemporaryPillar(npc);}
    public boolean isManual(){return active() && manual;}
    public boolean canStartAutomatic(){return npc.age>=idleCooldown && npc.age>=nextAutoCheck;}
    public void pause(){
        if(pausedAt<0)pausedAt=npc.age;
        mining.reset();stone.pause();npc.clearWorkingVisual();
    }
    public void resume(){
        stone.resume();
        if(pausedAt<0)return;
        int delay=npc.age-pausedAt;
        lastAction+=delay;lootStarted+=delay;huntStarted+=delay;waypointStarted+=delay;
        nextSearch+=delay;nextRoute=0;pausedAt=-1;
    }
    public boolean collectLooseDrops(){return !npc.menuOpen() && npc.autoLoot && seekDrops();}
    public boolean cleanupTick(){
        resume();
        if(!cleaning)return false;
        equipAxe();
        if(pillar.cleanup(mining))return true;
        if(!pillar.active())cleaning=false;
        return false;
    }
    private void deferTree(int delay){
        if(tree==null || treeLogs.isEmpty())return;
        deferredTrees.removeIf(t->t.base().equals(tree));
        if(deferredTrees.size()>=8)deferredTrees.remove(0);
        long now=npc.getWorld().getTime();
        deferredTrees.add(new DeferredTree(tree,java.util.List.copyOf(treeLogs),now+delay,now+24000));
        npc.intelligence().memory().failed(tree,now);
    }
    private boolean resumeDeferredTree(){
        long now=npc.getWorld().getTime();
        deferredTrees.removeIf(t->t.expires()<=now);
        var iterator=deferredTrees.iterator();
        while(iterator.hasNext()){
            var task=iterator.next();
            if(task.retry()>now || task.base().getSquaredDistance(npc.getBlockPos())>24*24
                    || !safe(task.base()))continue;
            tree=task.base();treeLogs.clear();treeLogs.addAll(task.logs());iterator.remove();
            treeLogs.removeIf(p->!safe(p) || !npc.getWorld().getBlockState(p).isIn(BlockTags.LOGS)
                || (npc.getWorld() instanceof ServerWorld world && OwnedBlocks.get(world).protectedBlock(p)));
            if(!treeLogs.isEmpty()){nextSearch=0;return true;}
            tree=null;
        }
        return false;
    }
    public void navigationFailed(BlockPos destination){
        if(kind==Kind.STONE)stone.failed();
        if(tree!=null){
            deferTree(400);
            npc.intelligence().memory().failed(tree,npc.getWorld().getTime());
            avoidedTrees.put(tree,npc.age+400);
            tree=null;treeLogs.clear();cleaning=pillar.active();
        }
        waypoint=null;animal=null;nextRoute=0;mining.reset();
    }
    public NbtCompound taskSnapshot(){
        NbtCompound root=new NbtCompound();writeNbt(root);
        NbtCompound task=new NbtCompound();
        if(root.contains("GatherTask"))task.put("GatherTask",root.getCompound("GatherTask").copy());
        return task;
    }
    public void restoreTask(NbtCompound snapshot){
        if(kind==Kind.WOOD && active())deferTree(200);
        NbtCompound root=new NbtCompound();writeNbt(root);
        root.remove("GatherTask");
        if(snapshot.contains("GatherTask"))root.put("GatherTask",snapshot.getCompound("GatherTask").copy());
        readNbt(root);pausedAt=-1;
    }
    /** A committed physical action must finish before voluntary following can interrupt it. */
    public boolean canYieldToOwner() {
        return (!active() || (!manual && !mining.hasProgress() && !stone.committed()))
            && !pillar.active() && !cleaning;
    }
    public boolean miningStone(){return kind==Kind.STONE && stone.committed();}
    public boolean active() {return kind!=Kind.NONE;}
    public boolean cleanupReady(){return cleaning && pillar.cleanupReady();}
    public boolean hasCleanup() {return cleaning;}
    public Kind kind() {return kind;}
    public int progress() {return gathered;}
    public int goal() {return desired;}
    private void tell(String text) {if(manual && npc.owner()!=null)npc.owner().sendMessage(Text.literal("[AI Player] "+text),false);}
    public void start(Kind task,int count,boolean fromPlayer) {
        if (task==Kind.NONE) {cancel(); return;}
        if(fromPlayer)npc.intelligence().clearSuspended();
        pausedAt=-1;mining.reset();stone.reset();treeLogs.clear();cleaning=pillar.active();lootTarget=null;nextRoute=0;
        searching=false;kind=task; desired=Math.max(1,Math.min(264,count)); gathered=0;
        manual=fromPlayer; if(!fromPlayer)lastAutoKind=task; origin=npc.getBlockPos().toImmutable(); tree=null; animal=null;waypoint=null;waypointIndex=0;
        lastAction=npc.age; nextSearch=0; noProgressTicks=0;attackCooldown=0;
        npc.getNavigation().stop();
        tell("Bora, meu rei! Vou buscar "+desired+(kind==Kind.WOOD?" troncos de madeira.":kind==Kind.STONE?" pedregulhos de pedra exposta.":" alimentos."));
    }
    public void cancel() {npc.intelligence().clearSuspended();if(active())tell("Tá certo, parei por aqui ("+gathered+"/"+desired+").");finish(false);}
    private void finish(boolean done) {
        if(done)tell("Pronto, meu rei! Consegui "+gathered+"/"+desired+(kind==Kind.WOOD?" troncos.":kind==Kind.STONE?" pedregulhos.":" alimentos."));
        stone.reset();kind=Kind.NONE;tree=null;treeLogs.clear();animal=null;waypoint=null;mining.reset();cleaning=pillar.active();npc.getNavigation().stop();
        if(done)npc.intelligence().memory().succeeded("Coleta verificada: "+gathered+"/"+desired);
        idleCooldown=npc.age+(done?60:160);
    }
    /** Called by the movement goal only when there is no threat and the NPC is healthy. */
    public boolean tick() {
        if (cleaning) {
            equipAxe();
            if (pillar.cleanup(mining)) return true;
            if(pillar.active())return false; // Preserve ownership while an unreachable cleanup yields movement.
            cleaning=false;
        }
        if(!active())return false;
        if(npc.menuOpen() || npc.isEating() || npc.getTarget()!=null)return true;
        if(attackCooldown>0)attackCooldown--;
        if(gathered>=desired && treeLogs.isEmpty()){
            if(!pillar.active()) {nextDropScan=0;if(seekDrops())return true;}
            finish(true);return true;
        }
        if(origin!=null && npc.getBlockPos().getSquaredDistance(origin)>50*50) {
            tell("Fui longe demais da área de coleta, viu? Vou parar essa busca.");finish(false);return true;
        }
        if(npc.age-lastAction>850) {tell("Oxe, não tô conseguindo avançar. Vou parar essa tarefa pra não ficar insistindo à toa.");finish(false);return true;}
        // Commit to one physical block, including leaves cleared to reach a drop.
        // Combat and explicit orders can still pause through the coordinator.
        if(mining.hasProgress()){
            BlockPos committed=mining.target();
            if(mining.reachable(committed)){
                if(mining.tick(committed)){treeLogs.remove(committed);lastAction=npc.age;}
                return true;
            }
            mining.reset();
        }
        if(kind==Kind.STONE && stone.committed()){stoneTick();return true;}
        if(!pillar.active() && seekDrops())return true;
        if(kind==Kind.STONE){stoneTick();return true;}
        if(kind==Kind.WOOD) {
            if(dev.aiplayer.ai.brain.ResourcePlan.inspect(npc).full())return false;
            woodTick();return true;
        }
        return foodTick();
    }
    private void stoneTick(){
        if(!npc.autoLoot){tell("Ative a coleta de drops pra eu recolher os pedregulhos, meu rei.");finish(false);return;}
        switch(stone.tick()){
            case MINED -> lastAction=npc.age;
            case NEED_TOOL -> {tell("Preciso de uma picareta em condições, sem Toque Suave, na mão. Ative fabricação/equipamento automático ou me entregue uma, viu?");finish(false);}
            case EXHAUSTED -> {tell("Não achei pedra exposta com acesso seguro num raio de 32 blocos, meu rei.");if(!manual)npc.speech().notice(CompanionSpeech.Event.NO_STONE);finish(false);idleCooldown=npc.age+1200;}
            case RULE_BLOCKED -> {tell("As regras do mundo impedem quebrar blocos ou gerar drops, viu?");finish(false);idleCooldown=npc.age+1200;}
            default -> { }
        }
    }
    private int woodInBag() {
        int n=0;
        for(int i=0;i<npc.backpack.size();i++){ItemStack s=npc.backpack.getStack(i);if(s.isIn(ItemTags.LOGS))n+=s.getCount();}
        return n;
    }
    private int planksInBag() {
        int n=0;
        for(int i=0;i<npc.backpack.size();i++){ItemStack s=npc.backpack.getStack(i);if(s.isIn(ItemTags.PLANKS))n+=s.getCount();}
        return n;
    }
    private boolean foodItem(ItemStack item) {
        if(!item.isFood())return false;
        return !item.isOf(Items.ROTTEN_FLESH) && !item.isOf(Items.POISONOUS_POTATO)
            && !item.isOf(Items.SPIDER_EYE) && !item.isOf(Items.PUFFERFISH) && !item.isOf(Items.CHICKEN);
    }
    private int foodInBag() {
        int n=0;
        for(int i=0;i<npc.backpack.size();i++){ItemStack s=npc.backpack.getStack(i);if(foodItem(s))n+=s.getCount();}
        return n;
    }
    private static boolean isSoil(BlockState state) {
        return state.isIn(BlockTags.DIRT) || state.isOf(Blocks.GRASS_BLOCK)
             || state.isOf(Blocks.PODZOL) || state.isOf(Blocks.MYCELIUM);
    }
    private boolean safe(BlockPos p) {
        return npc.getWorld().isChunkLoaded(p) && p.getY()>npc.getWorld().getBottomY()+2
            && p.getY()<npc.getWorld().getTopY()-2;
    }
    private boolean treeBase(BlockPos p) {
        if(npc.getWorld() instanceof ServerWorld world && (OwnedBlocks.get(world).protectedBlock(p) || OwnedBlocks.get(world).claimed(p)))return false;
        if(!safe(p) || !safe(p.up(3)) || !npc.getWorld().getBlockState(p).isIn(BlockTags.LOGS)
                || !isSoil(npc.getWorld().getBlockState(p.down())))return false;
        // A vertical trunk, connected to its own leaf canopy; horizontal logs near leaves do not qualify.
        int height=0;
        while(height<32 && safe(p.up(height)) && npc.getWorld().getBlockState(p.up(height)).isIn(BlockTags.LOGS))height++;
        if(height<3)return false;
        for(int dy=-2;dy<=2;dy++)for(int dx=-2;dx<=2;dx++)for(int dz=-2;dz<=2;dz++) {
            BlockPos leaf=p.up(height).add(dx,dy,dz);
            if(safe(leaf) && npc.getWorld().getBlockState(leaf).isIn(BlockTags.LEAVES))return true;
        }
        return false;
    }
    private static final java.util.List<BlockPos> SEARCH_COLUMNS=java.util.stream.IntStream.rangeClosed(-32,32).boxed()
        .flatMap(x->java.util.stream.IntStream.rangeClosed(-32,32).mapToObj(z->new BlockPos(x,0,z)))
        .filter(p->p.getX()*p.getX()+p.getZ()*p.getZ()<=32*32)
        .sorted(Comparator.comparingDouble(p->p.getSquaredDistance(BlockPos.ORIGIN))).toList();
    private BlockPos searchCenter;
    private int searchColumn;
    private boolean searching;
    public String searchStatus(){return "column="+searchColumn+" pending="+searching+" center="+searchCenter;}
    private BlockPos findTree() {
        BlockPos center=npc.getBlockPos();
        var remembered=npc.intelligence().memory().nearest("tree",center,npc.getWorld().getTime(),36);
        if(remembered.isPresent() && avoidedTrees.getOrDefault(remembered.get(),0)<=npc.age
                && treeBase(remembered.get())){searching=false;return remembered.get();}
        if(!searching){searchCenter=center.toImmutable();searchColumn=0;searching=true;}
        // Budgeted, nearest-first scan: no skipped odd columns and no giant synchronous scan.
        for(int budget=0;budget<96 && searchColumn<SEARCH_COLUMNS.size();budget++,searchColumn++){
            BlockPos column=searchCenter.add(SEARCH_COLUMNS.get(searchColumn));
            for(int dy=-12;dy<=12;dy++){
                BlockPos p=column.up(dy);
                if((origin!=null && p.getSquaredDistance(origin)>50*50)
                    || avoidedTrees.getOrDefault(p,0)>npc.age
                    || npc.intelligence().memory().blocked(p,npc.getWorld().getTime()) || !treeBase(p))continue;
                npc.intelligence().memory().remember("tree",p,npc.getWorld().getTime(),12000);
                searching=false;return p;
            }
        }
        if(searchColumn>=SEARCH_COLUMNS.size())searching=false;
        return null;
    }
    private void equipAxe() {
        if(!npc.autoEquip)return;
        if(npc.getMainHandStack().getItem() instanceof AxeItem)return;
        int best=-1;float speed=0;
        for(int i=0;i<npc.backpack.size();i++){
            ItemStack s=npc.backpack.getStack(i);
            if(s.getItem() instanceof AxeItem axe && s.getCount()==1) {
                float value=axe.getMaterial().getMiningSpeedMultiplier();
                if(value>speed){speed=value;best=i;}
            }
        }
        if(best>=0) {
            ItemStack selected=npc.backpack.removeStack(best);
            ItemStack old=npc.getMainHandStack();
            npc.equipStack(EquipmentSlot.MAINHAND,selected);
            npc.backpack.setStack(best,old);
        }
    }
    private boolean travelSearchPoint() {
        if(waypoint!=null && npc.age-waypointStarted>100)waypoint=null;
        if(waypoint!=null && npc.squaredDistanceTo(Vec3d.ofCenter(waypoint))>4.5*4.5) {
            if(npc.age%30==0 && !WorkNavigation.moveNear(npc,waypoint,waypoint.getY(),1.15))waypoint=null;
            return true;
        }
        waypoint=null;
        // Bounded outward search (not a scan of unloaded chunks). A manual order reaches farther.
        int[][] choices={{12,0},{0,12},{-12,0},{0,-12},{20,10},{-20,10},{20,-10},{-20,-10},
            {30,0},{0,30},{-30,0},{0,-30},{34,22},{-34,22},{34,-22},{-34,-22}};
        int limit=manual?choices.length:4;
        while(waypointIndex<limit) {
            int[] delta=choices[waypointIndex++];
            BlockPos base=origin.add(delta[0],0,delta[1]);
            for(int dy=2;dy>=-3;dy--) {
                BlockPos p=base.up(dy);
                if(!safe(p) || !safe(p.up()) || !safe(p.down()))continue;
                if(!npc.getWorld().getBlockState(p).isAir() || !npc.getWorld().getBlockState(p.up()).isAir()
                    || !npc.getWorld().getBlockState(p.down()).isSolidBlock(npc.getWorld(),p.down()))continue;
                if(!WorkNavigation.moveNear(npc,p,p.getY(),1.15))continue;
                waypoint=p.toImmutable();waypointStarted=npc.age;lastAction=npc.age;return true;
            }
        }
        return false;
    }
    private void skipDrop() {skipDrop(300);}
    private void skipDrop(int retryDelay) {
        if(lootTarget!=null)avoidedDrops.put(lootTarget.getUuid(),npc.age+retryDelay);
        lootTarget=null;mining.reset();npc.getNavigation().stop();
    }
    private boolean clearLeafToward(Vec3d target) {
        BlockPos leaf=WorkNavigation.leafBetween(npc,target);
        if(leaf==null || !mining.reachable(leaf))return false;
        if(mining.tick(leaf))lastAction=npc.age;
        return true;
    }
    private boolean seekDrops() {
        if(!npc.autoLoot)return false;
        avoidedDrops.entrySet().removeIf(e -> e.getValue()<=npc.age);
        if(lootTarget!=null && (!lootTarget.isAlive() || npc.age-lootStarted>120
                || !npc.backpack.canInsert(lootTarget.getStack())))skipDrop();
        if(lootTarget==null && npc.age>=nextDropScan) {
            nextDropScan=npc.age+10;
            lootTarget=npc.getWorld().getEntitiesByClass(net.minecraft.entity.ItemEntity.class,
                npc.getBoundingBox().expand(8),d -> d.isAlive() && !d.cannotPickup()
                    && !avoidedDrops.containsKey(d.getUuid()) && npc.backpack.canInsert(d.getStack())
                    && (kind==Kind.NONE || (kind==Kind.WOOD && d.getStack().isIn(ItemTags.LOGS))
                        || (kind==Kind.FOOD && foodItem(d.getStack()))
                        || (kind==Kind.STONE && d.getStack().isOf(Items.COBBLESTONE))))
                .stream().min(Comparator.comparingDouble(d -> npc.squaredDistanceTo(d)
                    -(d.getCommandTags().contains("aiplayer_drop_"+npc.getUuid())?1000:0))).orElse(null);
            lootStarted=npc.age;
        }
        if(lootTarget==null)return false;
        if(lootTarget.getStack().isIn(ItemTags.LOGS)) {
            // Remove the actual leaf supporting the item, then let gravity bring it down.
            BlockPos support=lootTarget.getBlockPos().down();
            if(npc.getWorld().getBlockState(support).isIn(BlockTags.LEAVES) && mining.reachable(support)) {
                if(mining.tick(support))lastAction=npc.age;
                return true;
            }
            if(clearLeafToward(lootTarget.getPos()))return true;
        }
        if(lootTarget.getY()>npc.getY()+2.5) {skipDrop();return false;}
        mining.reset();
        if(npc.squaredDistanceTo(lootTarget)<2.7)return true;
        if(npc.age>=nextRoute) {
            nextRoute=npc.age+20;
            // Pathfinding can fail briefly while landing or while the drop is still falling.
            // Retry soon instead of forgetting reachable resources for fifteen seconds.
            if(!WorkNavigation.moveToDrop(npc,lootTarget,1.1)) {skipDrop(40);return false;}
        }
        return true;
    }
    private void captureTree() {
        treeLogs.clear();
        java.util.ArrayDeque<BlockPos> todo=new java.util.ArrayDeque<>();
        java.util.Set<BlockPos> seen=new java.util.HashSet<>();
        todo.add(tree);seen.add(tree);
        while(!todo.isEmpty() && treeLogs.size()<160) {
            BlockPos p=todo.removeFirst();
            if(!safe(p) || pillar.owns(p) || !npc.getWorld().getBlockState(p).isIn(BlockTags.LOGS))continue;
            if(npc.getWorld() instanceof ServerWorld world && (OwnedBlocks.get(world).protectedBlock(p) || OwnedBlocks.get(world).claimed(p)))continue;
            treeLogs.add(p);
            for(int x=-1;x<=1;x++)for(int y=-1;y<=1;y++)for(int z=-1;z<=1;z++) {
                BlockPos q=p.add(x,y,z);
                if(q.getY()<tree.getY() || q.getY()>tree.getY()+30
                    || Math.abs(q.getX()-tree.getX())>6 || Math.abs(q.getZ()-tree.getZ())>6)continue;
                if(seen.add(q))todo.add(q);
            }
        }
    }
    private void woodTick() {
        if(npc.age < nextSearch)return;
        if(tree==null)resumeDeferredTree();
        if(tree==null || !safe(tree)){
            tree=findTree();nextSearch=npc.age+(searching?1:30);
            if(tree==null){
                if(searching)return;
                if(travelSearchPoint())return;
                if(npc.age-lastAction>160){if(!manual)npc.speech().notice(CompanionSpeech.Event.NO_TREE);tell("Meu rei, não achei árvore natural acessível nessa busca. Pode ter madeira mais adiante ou algum caminho bloqueado.");finish(false);}
                return;
            }
            captureTree();waypoint=null;
        }
        treeLogs.removeIf(p -> safe(p) && !npc.getWorld().getBlockState(p).isIn(BlockTags.LOGS));
        if(treeLogs.isEmpty()) {tree=null;cleaning=pillar.active();mining.reset();return;}
        equipAxe();
        if(pillar.isJumping()){pillar.climb();return;}
        BlockPos committed=mining.target();
        BlockPos cut=committed!=null && treeLogs.contains(committed) && mining.reachable(committed)?committed:treeLogs.stream().filter(mining::reachable)
            .min(Comparator.comparingDouble(p -> npc.getEyePos().squaredDistanceTo(Vec3d.ofCenter(p)))).orElse(null);
        if(cut!=null) {
            if(mining.tick(cut)){treeLogs.remove(cut);lastAction=npc.age;}
            return;
        }
        BlockPos lowest=treeLogs.stream().min(Comparator.comparingInt(BlockPos::getY)).orElse(tree);
        // Open the line of sight to the trunk at any height, not only directly overhead.
        if(clearLeafToward(Vec3d.ofCenter(lowest)))return;
        double horizontal=Math.pow(npc.getX()-lowest.getX()-0.5,2)+Math.pow(npc.getZ()-lowest.getZ()-0.5,2);
        if(lowest.getY()>npc.getY()+2 && horizontal<6.25) {
            // Clear only leaves immediately above the climbing body, with normal mining.
            for(int dy=2;dy<=3;dy++) {
                BlockPos overhead=npc.getBlockPos().up(dy);
                if(npc.getWorld().getBlockState(overhead).isIn(BlockTags.LEAVES) && mining.reachable(overhead)) {
                    if(mining.tick(overhead))lastAction=npc.age;
                    return;
                }
            }
            mining.reset();
            if(pillar.climb())return;
            deferTree(1200);avoidedTrees.put(tree,npc.age+1200);tree=null;treeLogs.clear();cleaning=pillar.active();return;
        }
        mining.reset();
        if(pillar.active()){cleaning=true;return;}
        if(npc.age>=nextRoute) {
            nextRoute=npc.age+25;
            if(!WorkNavigation.moveNear(npc,lowest,tree.getY(),1.18)) {
                npc.speech().notice(CompanionSpeech.Event.ROUTE);
                deferTree(400);avoidedTrees.put(tree,npc.age+400);tree=null;treeLogs.clear();
                noProgressTicks=0;nextSearch=npc.age+10;return;
            }
        }
        if(npc.age%40==0)checkStuck();
    }
    private void checkStuck() {
        Vec3d now=npc.getPos();
        if(now.squaredDistanceTo(lastLocation)<0.18)noProgressTicks+=40;else noProgressTicks=0;
        lastLocation=now;
        if(noProgressTicks>=160){deferTree(1200);if(tree!=null)avoidedTrees.put(tree,npc.age+1200);treeLogs.clear();tree=null;noProgressTicks=0;nextSearch=npc.age+25;}
    }
    private boolean prey(AnimalEntity a) {
        return a.isAlive() && !a.isBaby() && (a instanceof CowEntity || a instanceof PigEntity
                || a instanceof SheepEntity || a instanceof RabbitEntity);
    }
    private boolean foodTick() {
        // A failed scan does not own movement: following and strolling may run meanwhile.
        if(npc.age<nextSearch)return false;
        avoidedAnimals.entrySet().removeIf(e -> e.getValue()<=npc.age);
        if(animal!=null && npc.age-huntStarted>100) {
            avoidedAnimals.put(animal.getUuid(),npc.age+400);
            animal=null;npc.getNavigation().stop();
        }
        if(animal==null || !prey(animal) || animal.squaredDistanceTo(npc)>25*25) {
            animal=npc.getWorld().getEntitiesByClass(AnimalEntity.class,npc.getBoundingBox().expand(14),
                    a -> prey(a) && !avoidedAnimals.containsKey(a.getUuid()))
                    .stream().min(Comparator.comparingDouble(npc::squaredDistanceTo)).orElse(null);
            huntStarted=npc.age;
            if(animal==null) {
                if(npc.age-lastAction>160){if(!manual)npc.speech().notice(CompanionSpeech.Event.NO_FOOD);tell("Não achei animal adequado pra conseguir comida por aqui, viu?");finish(false);}
                nextSearch=npc.age+30;return false;
            }
        }
        if(npc.autoEquip)npc.optimizeEquipment();
        if(npc.squaredDistanceTo(animal)>2.5*2.5 || !npc.canSee(animal)) {
            if(npc.age>=nextRoute) {
                nextRoute=npc.age+15;
                if(!npc.getNavigation().startMovingTo(animal,1.23)) {
                    avoidedAnimals.put(animal.getUuid(),npc.age+400);
                    animal=null;return false;
                }
            }
            return true;
        }
        npc.getNavigation().stop();
        npc.getLookControl().lookAt(animal,30,30);
        if(attackCooldown==0){
            npc.tryAttack(animal);
            attackCooldown=20;lastAction=npc.age;huntStarted=npc.age;
        }
        if(!animal.isAlive()) {animal=null;nextSearch=npc.age+10;}
        return true;
    }
    /** Called after SurvivalController picks up a legitimate food drop. */
    public void onCollected(ItemStack added) {
        if((kind==Kind.FOOD && foodItem(added)) || (kind==Kind.WOOD && added.isIn(ItemTags.LOGS)) || (kind==Kind.STONE && added.isOf(Items.COBBLESTONE))) {
            gathered+=added.getCount();lastAction=npc.age;
        }
    }
    public void writeNbt(NbtCompound nbt) {
        pillar.writeNbt(nbt);
        net.minecraft.nbt.NbtList deferred=new net.minecraft.nbt.NbtList();
        for(var t:deferredTrees){
            NbtCompound data=new NbtCompound();data.putLong("Base",t.base().asLong());data.putLong("Retry",t.retry());data.putLong("Expires",t.expires());
            data.putLongArray("Logs",t.logs().stream().mapToLong(BlockPos::asLong).toArray());deferred.add(data);
        }
        nbt.put("DeferredTrees",deferred);
        if(!active())return;
        NbtCompound data=new NbtCompound();
        data.putString("Kind",kind.name());data.putInt("Desired",desired);data.putInt("Gathered",gathered);
        data.putBoolean("Manual",manual);
        if(origin!=null){data.putInt("X",origin.getX());data.putInt("Y",origin.getY());data.putInt("Z",origin.getZ());}
        if(tree!=null)data.putLong("Tree",tree.asLong());
        data.putLongArray("Logs",treeLogs.stream().mapToLong(BlockPos::asLong).toArray());
        nbt.put("GatherTask",data);
    }
    public void readNbt(NbtCompound nbt) {
        // On load or nested-job restoration, routes and item entities from the old
        // activity must never bleed into the restored task. Only durable goals,
        // ownership and deferred trees are read from NBT.
        mining.reset();stone.reset();pausedAt=-1;kind=Kind.NONE;tree=null;animal=null;
        lootTarget=null;lootStarted=0;nextDropScan=0;nextRoute=0;nextSearch=0;
        waypoint=null;waypointIndex=0;idleCooldown=0;searching=false;searchCenter=null;searchColumn=0;
        lastLocation=npc.getPos();noProgressTicks=0;attackCooldown=0;
        treeLogs.clear();pillar.readNbt(nbt);cleaning=pillar.active();
        deferredTrees.clear();
        var deferred=nbt.getList("DeferredTrees",net.minecraft.nbt.NbtElement.COMPOUND_TYPE);
        for(int i=0;i<Math.min(8,deferred.size());i++){
            var data=deferred.getCompound(i);java.util.List<BlockPos> logs=new java.util.ArrayList<>();
            for(long pos:data.getLongArray("Logs"))if(logs.size()<160)logs.add(BlockPos.fromLong(pos));
            deferredTrees.add(new DeferredTree(BlockPos.fromLong(data.getLong("Base")),logs,data.getLong("Retry"),data.getLong("Expires")));
        }
        if(!nbt.contains("GatherTask"))return;
        NbtCompound data=nbt.getCompound("GatherTask");
        try {kind=Kind.valueOf(data.getString("Kind"));}catch(IllegalArgumentException ex){kind=Kind.NONE;}
        desired=Math.max(1,Math.min(264,data.getInt("Desired")));gathered=Math.max(0,data.getInt("Gathered"));
        manual=data.getBoolean("Manual");origin=new BlockPos(data.getInt("X"),data.getInt("Y"),data.getInt("Z"));
        if(data.contains("Tree"))tree=BlockPos.fromLong(data.getLong("Tree"));
        for(long pos:data.getLongArray("Logs"))if(treeLogs.size()<160)treeLogs.add(BlockPos.fromLong(pos));
        lastAction=npc.age;
    }
}
