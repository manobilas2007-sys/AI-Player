package dev.aiplayer.ai;

import dev.aiplayer.entity.CompanionEntity;
import dev.aiplayer.ai.brain.ResourcePlan;
import net.minecraft.block.*;
import net.minecraft.item.*;
import net.minecraft.enchantment.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.ai.pathing.Path;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.*;
import java.util.*;

/** Surface-only work. The coordinator owns interruption; this executor owns one committed block. */
public final class SurfaceStoneGathering {
    public enum Result { ACTIVE, MINED, EXHAUSTED, NEED_TOOL, RULE_BLOCKED }
    private static final List<BlockPos> COLUMNS=java.util.stream.IntStream.rangeClosed(-32,32).boxed()
        .flatMap(x->java.util.stream.IntStream.rangeClosed(-32,32).mapToObj(z->new BlockPos(x,0,z)))
        .filter(p->p.getX()*p.getX()+p.getZ()*p.getZ()<=1024)
        .sorted(Comparator.comparingDouble(p->p.getSquaredDistance(BlockPos.ORIGIN))).toList();
    private final CompanionEntity npc;
    private final PhysicalMining mining;
    private BlockPos center,target,stance;
    private int column,height=-8,passes,waitUntil,nextRoute,routeStarted,paused=-1;
    private Vec3d routePosition;
    private final Map<BlockPos,Long> avoided=new HashMap<>();
    public SurfaceStoneGathering(CompanionEntity npc){this.npc=npc;mining=new PhysicalMining(npc,SurfaceStoneGathering::suitablePick);}
    public static boolean suitablePick(ItemStack s){
        return s.getItem() instanceof PickaxeItem && !ResourcePlan.worn(s)
            && s.isSuitableFor(Blocks.STONE.getDefaultState()) && EnchantmentHelper.getLevel(Enchantments.SILK_TOUCH,s)==0;
    }
    public static boolean hasPick(CompanionEntity npc){
        if(suitablePick(npc.getMainHandStack()))return true;
        if(npc.autoEquip)for(int i=0;i<npc.backpack.size();i++)if(suitablePick(npc.backpack.getStack(i)))return true;
        return false;
    }
    public boolean committed(){return mining.hasProgress();}
    public void pause(){if(paused<0)paused=npc.age;mining.reset();}
    public void resume(){if(paused>=0){int delay=npc.age-paused;waitUntil+=delay;routeStarted+=delay;paused=-1;}}
    public void reset(){mining.reset();center=null;target=null;stance=null;column=0;height=-8;passes=0;waitUntil=0;nextRoute=0;paused=-1;avoided.clear();}
    public void failed(){
        if(target!=null){avoided.put(target,npc.getWorld().getTime()+100);npc.intelligence().memory().failed(target,npc.getWorld().getTime());}
        target=null;stance=null;mining.reset();npc.getNavigation().stop();
    }
    public boolean safeBlock(BlockPos p){
        if(!(npc.getWorld() instanceof ServerWorld world) || !world.isChunkLoaded(p)
            || !world.getBlockState(p).isOf(Blocks.STONE) || OwnedBlocks.get(world).protectedBlock(p) || OwnedBlocks.get(world).claimed(p))return false;
        if(new Box(p).stretch(0,1,0).intersects(npc.getBoundingBox())
            || !world.getEntitiesByClass(LivingEntity.class,new Box(p.up()),e->e.isAlive() && e!=npc).isEmpty())return false;
        for(Direction dir:Direction.values())if(!world.isChunkLoaded(p.offset(dir)) || !world.getFluidState(p.offset(dir)).isEmpty())return false;
        return !(world.getBlockState(p.up()).getBlock() instanceof FallingBlock);
    }
    private boolean standable(BlockPos p,BlockPos block){
        var world=npc.getWorld();
        if(p.down().equals(block) || !world.isChunkLoaded(p) || !world.isSkyVisible(p.up())
            || !world.getFluidState(p).isEmpty() || !world.getFluidState(p.up()).isEmpty()
            || !world.getBlockState(p.down()).isSolidBlock(world,p.down()))return false;
        var floor=world.getBlockState(p.down());
        if(floor.isOf(Blocks.MAGMA_BLOCK)||floor.isOf(Blocks.CAMPFIRE)||floor.isOf(Blocks.SOUL_CAMPFIRE))return false;
        if(!WorkNavigation.safeWorkFooting(npc,p))return false;
        return !world.getBlockCollisions(npc,new Box(p.getX()+0.15,p.getY()+0.01,p.getZ()+0.15,p.getX()+0.85,p.getY()+2,p.getZ()+0.85)).iterator().hasNext();
    }
    private boolean surfaceRoute(Path path,int y){
        if(!WorkNavigation.surfacePath(npc,path,y))return false;
        for(int i=0;i<path.getLength();i++){
            var node=path.getNode(i);
            if(!npc.getWorld().isSkyVisible(new BlockPos(node.x,node.y+2,node.z)))return false;
        }
        return true;
    }
    private void selected(BlockPos block,BlockPos feet){
        target=block.toImmutable();stance=feet.toImmutable();routeStarted=npc.age;routePosition=npc.getPos();nextRoute=0;
        npc.intelligence().memory().remember("surface_stone",target,npc.getWorld().getTime(),24000);
    }
    private boolean select(BlockPos p){
        if(avoided.getOrDefault(p,0L)>npc.getWorld().getTime() || !safeBlock(p))return false;
        List<BlockPos> spots=new ArrayList<>();
        for(Direction dir:Direction.Type.HORIZONTAL)for(int dy=0;dy<=1;dy++){
            BlockPos feet=p.offset(dir).up(dy);if(standable(feet,p))spots.add(feet);
        }
        if(spots.isEmpty())return false;
        if(standable(npc.getBlockPos(),p) && mining.reachable(p)){selected(p,npc.getBlockPos());return true;}
        for(BlockPos feet:spots){
            Path path=npc.getNavigation().findPathTo(feet,0);
            if(surfaceRoute(path,feet.getY())){selected(p,feet);return true;}
        }
        avoided.put(p,npc.getWorld().getTime()+50);return false;
    }
    public String diagnostics(BlockPos p){return "safe="+safeBlock(p)+" ground="+npc.isOnGround()+" reachable="+mining.reachable(p)+" standable="+standable(npc.getBlockPos(),p)+" state="+npc.getWorld().getBlockState(p)+" target="+target+" column="+column;}
    public Result tick(){
        resume();
        if(!npc.getWorld().getGameRules().getBoolean(net.minecraft.world.GameRules.DO_MOB_GRIEFING)
            || !npc.getWorld().getGameRules().getBoolean(net.minecraft.world.GameRules.DO_TILE_DROPS))return Result.RULE_BLOCKED;
        if(!hasPick(npc)){mining.reset();return Result.NEED_TOOL;}
        if(npc.age<waitUntil)return Result.ACTIVE;
        if(target!=null && (!safeBlock(target) || !standable(stance,target)))failed();
        if(target!=null){
            if(npc.isOnGround() && standable(npc.getBlockPos(),target) && mining.reachable(target)){
                if(mining.tick(target)){target=null;stance=null;passes=0;column=0;height=-8;waitUntil=npc.age+12;return Result.MINED;}
                return Result.ACTIVE;
            }
            if(routePosition==null || npc.getPos().squaredDistanceTo(routePosition)>0.5){routePosition=npc.getPos();routeStarted=npc.age;}
            if(npc.age-routeStarted>120){failed();return Result.ACTIVE;}
            // Do not throw away a functioning path every second. Repath only when idle
            // or when measurable progress has stopped, preventing stop/start shuffling.
            if(npc.age>=nextRoute && npc.isOnGround()
                    && (npc.getNavigation().isIdle() || npc.age-routeStarted>45)){
                nextRoute=npc.age+20;Path path=npc.getNavigation().findPathTo(stance,0);
                if(!surfaceRoute(path,stance.getY()) || !npc.getNavigation().startMovingAlong(path,1.1))failed();
            }
            return Result.ACTIVE;
        }
        // Navigation during a jump is not evidence that the destination is unreachable.
        if(!npc.isOnGround())return Result.ACTIVE;
        if(center==null){center=npc.getBlockPos().toImmutable();
            var memory=npc.intelligence().memory().nearest("surface_stone",center,npc.getWorld().getTime(),32);
            if(memory.isPresent() && select(memory.get()))return Result.ACTIVE;
        }
        int candidates=0;
        for(int budget=0;budget<1632 && column<COLUMNS.size();budget++){
            BlockPos o=COLUMNS.get(column),p=center.add(o.getX(),height,o.getZ());
            if(++height>8){height=-8;column++;}
            if(avoided.getOrDefault(p,0L)>npc.getWorld().getTime() || !safeBlock(p))continue;
            if(select(p))return Result.ACTIVE;
            if(++candidates==2)return Result.ACTIVE;
        }
        if(column<COLUMNS.size())return Result.ACTIVE;
        if(passes++<2){column=0;height=-8;waitUntil=npc.age+60;return Result.ACTIVE;}
        return Result.EXHAUSTED;
    }
}
