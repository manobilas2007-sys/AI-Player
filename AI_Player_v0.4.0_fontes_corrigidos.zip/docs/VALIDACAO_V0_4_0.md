# Evidências e limites da validação v0.4.0-dev

Data da revisão: 20/10/2026. Fonte: `AI_Player_v0.4.0_checkpoint.zip` enviado pelo usuário.

| Verificação | Realmente executada agora? | Resultado |
|---|---|---|
| Integridade e inspeção dos 79 itens originais | Sim | ZIP lido e extraído; Gradle, classes, resources e testes identificados |
| Testes do parser de ordens (`PortugueseOrderParserTest`) | Sim, com `javac --release 17` sobre JDK 21 | 38/38 aprovados |
| Testes da arbitragem (`DecisionPolicyTest`) | Sim, com `javac --release 17` sobre JDK 21 | 110 verificações aprovadas |
| Compilação com Loom e Minecraft/Yarn | Não | Não verificada; o wrapper não conseguiu baixar Gradle 8.7 (`UnknownHostException: services.gradle.org`) |
| Execução de GameTests no servidor Minecraft 1.20.1 | Não | Pendente pelo GitHub Actions; o código define 48 testes, incluindo 1 novo |
| Teste interativo no FCL, quedas e variação do relevo real | Não | Pendente no dispositivo |

A revisão não confunde os 46/47 GameTests **alegados pelo checkpoint** com execução recente. `docs/gametest-results-v0.3.9.xml` é histórico da versão anterior e não comprova nenhum teste de v0.4.0.

## Cenários prioritários para a primeira execução real

- `detectsStoneThirtyBlocksAway`: distância original preservada; arena alargada para evitar borda artificial e verificação extra para detectar queda.
- `refusesThinExposedBridgeForMining`: reprovar escolha de piso estreito com duas bordas altas.
- `physicalOrderStopsAfterThreePickups`: quebrar fisicamente três blocos, gastar três pontos de durabilidade e guardar exatamente três pedregulhos.
- `worldDropBeforeInventory`: verificar que a pedra se transforma primeiro em entidade de drop, sem crédito remoto ou duplicação.
- `makesPickAndResumesManualOrder`, `emptyInventoryWoodThenStone`: preparar a picareta de verdade, retornar ao trabalho anterior e manter a contagem.
- `autonomousThreeStoneTools`: consumir pedregulho real e fabricar as ferramentas de pedra.
- `savesAndCancelsMaterialSubgoal`: preservar/cancelar corretamente objetivo maior via NBT.
- Testes históricos de navegação, recuperação de degrau, pilares, combate, inventário, alimentação, bancada e falas (em `CompanionTests`).

## Pendências conhecidas

1. Compilação real e execução completa `runGametest` precisam de internet e do ambiente Fabric 1.20.1. **Não afirmar aprovação até conferir o relatório do GitHub Actions.**
2. A rejeição de caminhos estreitos é deliberadamente prudente. Avaliar in-game se estradas muito estreitas ou áreas rochosas naturais estão sendo recusadas em excesso. Se houver recusa, investigar o percurso e não afrouxar a proteção de forma cega.
3. Pilares que não tenham local seguro para descida/recuperação são preservados e a limpeza fica adiada. Isso evita quedas, mas pode exigir melhoria posterior de planejamento de saída.
4. Cenários com mobs, chunk descarregado, queda em água, encostas, outros mods, persistência após recarga do mundo, desempenho no Android/FCL e interferência do jogador ainda exigem teste manual.

## Reprodução das verificações locais

```sh
mkdir -p build/standalone-tests
javac --release 17 -encoding UTF-8 -d build/standalone-tests \
  src/main/java/dev/aiplayer/commands/PortugueseOrderParser.java \
  src/main/java/dev/aiplayer/ai/brain/DecisionPolicy.java \
  src/devtests/PortugueseOrderParserTest.java src/devtests/DecisionPolicyTest.java
java -cp build/standalone-tests PortugueseOrderParserTest
java -cp build/standalone-tests DecisionPolicyTest
```

Um `javac` sem as bibliotecas Minecraft não equivale a compilar o mod; mensagens de imports não resolvidos são esperadas. O GitHub Actions é a referência para a compilação e os GameTests completos.
