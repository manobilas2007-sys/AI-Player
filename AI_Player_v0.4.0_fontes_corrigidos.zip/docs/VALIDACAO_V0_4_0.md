# Evidências e limites da validação v0.4.0-dev

Data da revisão: 20/10/2026. Fonte: `AI_Player_v0.4.0_checkpoint.zip` enviado pelo usuário.

| Verificação | Realmente executada agora? | Resultado |
|---|---|---|
| Integridade e inspeção dos 79 itens originais | Sim | ZIP lido e extraído; Gradle, classes, resources e testes identificados |
| Testes do parser de ordens (`PortugueseOrderParserTest`) | Sim, com `javac --release 17` sobre JDK 21 | 38/38 aprovados |
| Testes da arbitragem (`DecisionPolicyTest`) | Sim, com `javac --release 17` sobre JDK 21 | 110 verificações aprovadas |
| Compilação Loom e Minecraft/Yarn do ZIP anterior | Sim, no GitHub Actions 39482902443 | Aprovada |
| GameTests do ZIP anterior | Sim, no GitHub Actions 39482902443 | 45 aprovados de 48; 3 falhas identificadas |
| Compilação e GameTests deste patch | Não | Pendente no GitHub Actions; **não reportar 48/48** |
| Teste interativo no FCL, quedas e variação do relevo real | Não | Pendente no dispositivo |

A revisão não confunde os 46/47 GameTests **alegados pelo checkpoint** com execução recente. `docs/gametest-results-v0.3.9.xml` é histórico da versão anterior e não comprova nenhum teste de v0.4.0.

## Cenários prioritários para a próxima execução real

- `detectsStoneThirtyBlocksAway`: distância original preservada; arena alargada para evitar borda artificial e verificação extra para detectar queda.
- `refusesThinExposedBridgeForMining`: reprovar escolha de piso estreito com duas bordas altas.
- `physicalOrderStopsAfterThreePickups`: quebrar fisicamente três blocos, gastar três pontos de durabilidade e guardar exatamente três pedregulhos.
- `worldDropBeforeInventory`: verificar que a pedra se transforma primeiro em entidade de drop, sem crédito remoto ou duplicação.
- `makesPickAndResumesManualOrder`, `emptyInventoryWoodThenStone`: preparar a picareta de verdade, retornar ao trabalho anterior e manter a contagem.
- `autonomousThreeStoneTools`: consumir pedregulho real e fabricar as ferramentas de pedra.
- `savesAndCancelsMaterialSubgoal`: preservar/cancelar corretamente objetivo maior via NBT.
- Testes históricos de navegação, recuperação de degrau, pilares, combate, inventário, alimentação, bancada e falas (em `CompanionTests`).

## Pendências conhecidas

1. O primeiro `runGametest` real passou em 45/48; a execução do ZIP com estas correções ainda precisa ocorrer. **Não afirmar aprovação até conferir o novo relatório do GitHub Actions.**
2. A rejeição de caminhos estreitos é deliberadamente prudente. Avaliar in-game se estradas muito estreitas ou áreas rochosas naturais estão sendo recusadas em excesso. Se houver recusa, investigar o percurso e não afrouxar a proteção de forma cega.
3. Pilares que não tenham local seguro para descida/recuperação são preservados e a limpeza fica adiada. Isso evita quedas, mas pode exigir melhoria posterior de planejamento de saída.
4. Cenários com mobs, chunk descarregado, queda em água, encostas, outros mods, persistência após recarga do mundo, desempenho no Android/FCL e interferência do jogador ainda exigem teste manual.

## Reprodução das verificações locais

```sh
mkdir -p build/standalone-tests
javac --release 17 -encoding UTF-8 -d build/standalone-tests \
  src/main/java/dev/aiplayer/commands/PortugueseOrderParser.java \
  src/main/java/dev/aiplayer/ai/brain/DecisionPolicy.java \
  src/devtests/PortugueseOrderParserTest.java src/devtests/DecisionPolicyTest.java
java -cp build/standalone-tests PortugueseOrderParserTest
java -cp build/standalone-tests DecisionPolicyTest
```

Um `javac` sem as bibliotecas Minecraft não equivale a compilar o mod; mensagens de imports não resolvidos são esperadas. O GitHub Actions é a referência para a compilação e os GameTests completos.

## Primeiro relatório real (GitHub Actions)

- [Execução #39482902443](https://github.com/manobilas2007-sys/AI-Player/actions/runs/39482902443) de 20/10/2026: `clean build compileTestmodJava` aprovado; 45/48 GameTests aprovados.
- `surfaceminingtests.detectsstonethirtyblocksaway`: teste comparava `a.getY()` absoluto com `1.9` relativo, provocando falso positivo de queda em mundo de testes situado em Y negativo. Patch compara Y absolutos e separa detecção de pedra da obtenção de rota.
- `companiontests.foodtaskcollectsloosewood`: o filtro anterior recusava troncos durante forrageamento, apesar de o teste exigir aproveitamento oportunista. Patch permite troncos e prioriza comida; somente comida atualiza progresso de FOOD.
- `companiontests.followingacceptsopenslope`: o teste construía três nós de subida no vazio, violando a exigência de apoio real. Patch cria uma rampa larga suportada, sem mudar as regras de segurança.
- O patch corrigido não teve Java/Minecraft reexecutados neste ambiente; 38/38 testes do parser e 110 verificações do escalonador executados localmente.
