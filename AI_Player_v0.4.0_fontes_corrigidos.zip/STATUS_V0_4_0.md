# AI Player v0.4.0-dev | patch após primeira execução real de GameTests (20/10/2026)

Origem: checkpoint v0.4.0, com melhorias anteriores preservadas. A execução do GitHub Actions [39482902443](https://github.com/manobilas2007-sys/AI-Player/actions/runs/39482902443) compilou os fontes e executou os **48 GameTests** do ZIP anterior: **45 aprovados, 3 falharam**. As falhas foram: `detectsStoneThirtyBlocksAway`, `foodTaskCollectsLooseWood` e `followingAcceptsOpenSlope`.

Este novo ZIP contém correções para os três cenários: teste de altura absoluta, memória de observação de pedra exposta mesmo antes de formar rota, coleta oportunista de troncos sem contabilizá-los como comida, e teste de encosta com solo construído de verdade.

Na revisão local do patch, os **38 testes de comandos** e **110 verificações da arbitragem** passaram novamente. **O patch ainda NÃO foi recompilado nem reexecutado no Minecraft**. O próximo GitHub Actions deve repetir a suíte completa; não presuma 48/48 aprovados.
