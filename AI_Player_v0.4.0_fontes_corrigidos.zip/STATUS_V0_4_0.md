# AI Player v0.4.0-dev | checkpoint revisado em 20/10/2026

Continuação fiel do ZIP v0.4.0 (base 0.3.9). Correções de rota de superfície, compromisso de mineração, seleção de drops, retomada de tarefas e limpeza de pilares. 38/38 testes de comandos e 110 verificações da política de prioridades executados e aprovados. Os 48 GameTests do código e o build de Fabric NÃO foram executados nesta revisão (Gradle 8.7 bloqueado por ausência de rede). Confira `README_V0_4_0.md` e `docs/VALIDACAO_V0_4_0.md` antes de usar em um mundo importante.
