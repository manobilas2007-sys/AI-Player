# Status — AI Player v0.4.1-dev

Fonte oficial: ZIP mais recente fornecido pelo usuário da v0.4.0 Work, com correções pontuais nas classes `CompanionIntelligence`, `StarterCrafting`, `TemporaryPillar`, nos GameTests e no workflow.

**Validação real nesta sessão:** 38 testes de comandos + 110 de prioridade + parsing de 36 fontes Java 17 aprovados.

**Pendente:** compilação completa Gradle/Fabric e 65 GameTests no Minecraft. Sem confirmação de 65/65. Ver docs/VALIDACAO_V0_4_1.md.

## Revisão de quatro regressões (21/10/2026)

Foram aplicadas alterações ao código real de `CompanionIntelligence`, `ResourceGathering`, `StarterCrafting` e `TemporaryPillar` para: manter ordens de pedra enquanto falta fabricar uma picareta, preferir pedregulho à coleta facultativa de troncos, fabricar ferramentas de pedra nos intervalos seguros da mineração, aproveitar a bancada própria antes de recuperá-la e melhorar a descida e reutilização física de apoios laterais. O GameTest da torre ganhou diagnóstico de estado sem alterar as verificações.

Validação nesta revisão: 38 testes do parser e 110 verificações de prioridades aprovados, 36 fontes Java analisados com sintaxe Java 17. O Gradle 8.7 não foi baixado no ambiente devido a `UnknownHostException: services.gradle.org`; **não houve nova execução dos 65 GameTests**. Último resultado de Minecraft, anterior a estas mudanças: **61/65**. Consulte `README_FIXES_v0.4.1.md` para detalhes e pendências.
