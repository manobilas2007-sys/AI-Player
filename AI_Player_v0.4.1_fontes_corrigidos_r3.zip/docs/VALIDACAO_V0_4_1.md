# AI Player v0.4.1-dev: validação da correção r2

Data: 21/10/2026.

## Última execução real no GitHub, ANTES desta correção

https://github.com/manobilas2007-sys/AI-Player/actions/runs/39611580104

- Compilação Fabric/Java 17: aprovada.
- 65 GameTests executados: 63 aprovados, 2 reprovados.
- Falhas: `surfaceminingtests.ownedbenchrecoveryyieldstomissingcobblestone` e `surfaceminingtests.emptyinventorywoodthenstone`.
- XML dessa execução anterior: `docs/gametest-results-v0.4.1-last-github-run.xml`.

## Mudanças desta correção r2

1. `CompanionIntelligence`: ordens de pedra com picareta pronta não cedem prioridade à recuperação opcional da bancada, mas a bancada própria obstrutiva pode ser removida fisicamente antes de uma tarefa de pedra automática. Receitas facultativas não substituem a busca do último pedregulho.
2. `SurfaceStoneGathering`: cobertura somente por folhas naturais não bloqueia mineração de superfície, nem é considerada entrada de caverna. Coberturas sólidas e riscos de terreno continuam sendo rejeitados.
3. `StarterCrafting`: detecção de bancada própria adjacente, cuja remoção pode liberar passagem.
4. `ResourceGathering` e GameTests: diagnósticos com estado real de escavação nos testes remanescentes, sem mudar os critérios de aprovação.

## Validação local da r2

- Testes de comandos: 38/38 aprovados usando Java 17 (`--release 17`).
- Verificações de prioridade: 110/110 aprovadas.
- Parser de sintaxe Java 17 de 36 arquivos de `src/`: zero erros.
- ZIP íntegro contendo fontes, Gradle, recursos, workflow e GameTests.

**Pendentes:** compilação Fabric com dependências Minecraft e execução dos 65 GameTests desta revisão. Gradle indisponível localmente por falha de DNS na resolução de `services.gradle.org`. O resultado 63/65 pertence exclusivamente ao commit anterior.

## GitHub

Envie `AI_Player_v0.4.1_fontes_corrigidos_r2.zip` à raiz do repositório. Ele aparece depois do ZIP anterior na ordenação `sort -V` usada pelo workflow existente. Acompanhe a ação `Build AI Player Fabric 1.20.1`. Evite manter outros ZIPs r2 com nomes posteriores no repositório.
