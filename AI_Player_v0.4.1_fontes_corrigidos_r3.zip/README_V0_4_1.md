# AI Player v0.4.1-dev | Minecraft Java 1.20.1 / Fabric / Java 17

Esta revisão **continua** o checkpoint v0.4.0 do Work, preservando os sistemas, classes, recursos e testes existentes. Não é uma reconstrução do projeto.

## Correções e motivo

- **Ferramentas de pedra:** o coordenador agora prioriza a mineração física do pedregulho restante quando a tarefa de recuperar uma bancada está bloqueando a fabricação do machado. A bancada continua registrada como propriedade do NPC; não se fabrica sem materiais nem sem mesa acessível.
- **Torres temporárias altas:** ajuste na descida física para reduzir ultrapassagem do apoio lateral e esperar a coleta natural do bloco recuperado antes de começar a próxima descida quando não há reserva de andaime. Nenhum item é concedido por código: somente blocos quebrados através de `PhysicalMining` e coletados por contato.
- **Regressões:** adicionada uma checagem integrada para o caso bancada pendente + último pedregulho e ampliadas as mensagens de diagnóstico do teste da torre de seis blocos.
- **Versão/build:** `0.4.1-dev`, workflow atualizado para o ZIP e JAR desta versão.

## O que permanece inalterado

Inventário real; equipamentos e consumo de recursos; coleta de madeira; mineração em escadas e galerias 2x2; recuperação de blocos temporários; combate e proteção; alimentação; navegação; comandos em português; personalidade já implementada. Sem dependências adicionais.

## Compilação e GameTests

Com **JDK 17** e internet para obter as dependências: `bash gradlew clean build compileTestmodJava runGametest --no-daemon`. Para o GitHub Actions, instale o `.github/workflows/build-fabric.yml` deste pacote na raiz do repositório, preservando a estrutura interna do ZIP. O workflow existente no GitHub precisa ser atualizado para detectar `v0.4.1` e publicar `ai-player-0.4.1-dev.jar`; enviar apenas um ZIP à raiz não altera automaticamente o workflow já instalado.

**Estado da validação nesta entrega:** foram executados os testes de comandos e prioridades, além do parsing Java 17; GameTests Minecraft não executados por indisponibilidade da distribuição Gradle no ambiente deste chat. O relatório completo e a distinção entre histórico e execução atual estão em `docs/VALIDACAO_V0_4_1.md`.

Não use o JAR da v0.4.0 para testar as correções da v0.4.1.
