# AI Player v0.4.1-dev, revisão r2

**Anterior à revisão r2:** o GitHub executou 65 GameTests, 63 passaram, 2 falharam (bancada vs pedregulho e ordem de pedra após começar sem itens). Fonte: https://github.com/manobilas2007-sys/AI-Player/actions/runs/39611580104.

**Nesta revisão r2:** alterações localizadas na arbitragem bancada/pedra e na identificação de céu sombreado por folhas, com diagnósticos adicionais. Testes locais realizados: 38/38 do parser, 110/110 de prioridades e parsing Java 17 dos 36 arquivos. **GameTests da r2 pendentes.**

Consulte `docs/VALIDACAO_V0_4_1.md` para detalhes.
