package dev.aiplayer.test;

import dev.aiplayer.AIPlayer;
import dev.aiplayer.ai.*;
import dev.aiplayer.entity.CompanionEntity;
import net.fabricmc.fabric.api.gametest.v1.FabricGameTest;
import net.minecraft.test.*;
import net.minecraft.block.Blocks;
import net.minecraft.item.*;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.util.math.*;

/** In-game regression fixtures for genuinely navigable, non-vertical excavations. */
public final class ExcavationTests implements FabricGameTest {
    private CompanionEntity worker(TestContext c){
        for(int x=0;x<9;x++)for(int z=0;z<9;z++){
            c.setBlockState(new BlockPos(x,1,z),Blocks.DIRT);
            c.setBlockState(new BlockPos(x,0,z),Blocks.DIRT);
        }
        CompanionEntity a=c.spawnEntity(AIPlayer.COMPANION,new BlockPos(4,2,4));
        a.setMode(Mode.WAIT);a.autoSurvive=false;a.autoCraft=false;
        a.equipStack(EquipmentSlot.MAINHAND,new ItemStack(Items.WOODEN_PICKAXE));
        return a;
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="excavation",tickLimit=40)
    public void declinesShaftWithoutStepSupport(TestContext c){
        CompanionEntity a=worker(c);
        for(int x=0;x<9;x++)for(int z=0;z<9;z++)c.setBlockState(new BlockPos(x,0,z),Blocks.AIR);
        SafeExcavation e=new SafeExcavation(a,new PhysicalMining(a,SurfaceStoneGathering::suitablePick));
        c.assertFalse(e.beginStair(),"Attempted descent into unsupported shaft");c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="excavation",tickLimit=40)
    public void preservesPlayerCraftingTables(TestContext c){
        CompanionEntity a=worker(c);
        for(Direction d:Direction.Type.HORIZONTAL)c.setBlockState(new BlockPos(4,1,4).offset(d),Blocks.CRAFTING_TABLE);
        SafeExcavation e=new SafeExcavation(a,new PhysicalMining(a,SurfaceStoneGathering::suitablePick));
        c.assertFalse(e.beginStair(),"Started digging through a crafting table");c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="excavation",tickLimit=40)
    public void rejectsLavaBehindWall(TestContext c){
        CompanionEntity a=worker(c);
        c.setBlockState(new BlockPos(5,2,4),Blocks.STONE);
        c.setBlockState(new BlockPos(6,2,4),Blocks.LAVA);
        SafeExcavation e=new SafeExcavation(a,new PhysicalMining(a,SurfaceStoneGathering::suitablePick));
        c.assertFalse(e.beginGallery(c.getAbsolutePos(new BlockPos(5,2,4))),"Tunnel opened into hidden lava");c.complete();
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="excavation",tickLimit=320)
    public void cutsGalleryTwoHighTwoWideWithoutMiningFloor(TestContext c){
        CompanionEntity a=worker(c);
        a.setAiDisabled(true);
        BlockPos base=new BlockPos(4,2,4);
        for(int z=3;z<=4;z++)for(int y=2;y<=3;y++)c.setBlockState(new BlockPos(5,y,z),Blocks.STONE);
        SafeExcavation e=new SafeExcavation(a,new PhysicalMining(a,SurfaceStoneGathering::suitablePick));
        c.assertTrue(e.beginGallery(c.getAbsolutePos(new BlockPos(5,2,4))),"Valid gallery refused");
        for(int t=2;t<290;t++)c.runAtTick(t,e::tick);
        c.runAtTick(300,()->{
            for(int z=3;z<=4;z++)for(int y=2;y<=3;y++)
                c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(5,y,z))).isAir(),"Gallery not excavated at "+y+","+z);
            for(int z=3;z<=4;z++)c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(5,1,z))).isOf(Blocks.DIRT),"Excavated gallery floor");
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(4,1,4))).isOf(Blocks.DIRT),"Removed current support");
            c.complete();
        });
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="excavation",tickLimit=200)
    public void ceilingStoneCanBeMinedWithoutTouchingFooting(TestContext c){
        CompanionEntity a=worker(c);a.setAiDisabled(true);
        BlockPos ceiling=new BlockPos(4,4,4);
        c.setBlockState(ceiling,Blocks.STONE);
        SurfaceStoneGathering gather=new SurfaceStoneGathering(a);
        for(int t=2;t<155;t++)c.runAtTick(t,gather::tick);
        c.runAtTick(170,()->{
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(ceiling)).isAir(),"Safe ceiling stone was not mined");
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(4,1,4))).isOf(Blocks.DIRT),"Ceiling mining destroyed the footing");
            c.complete();
        });
    }
    @GameTest(templateName="aiplayer_test:surface_arena",batchId="excavation",tickLimit=160)
    public void descendingStairPreservesCurrentFloorAndNextFooting(TestContext c){
        CompanionEntity a=worker(c);a.setAiDisabled(true);
        Direction facing=a.getHorizontalFacing();
        BlockPos next=new BlockPos(4,2,4).offset(facing);
        SafeExcavation e=new SafeExcavation(a,new PhysicalMining(a,SurfaceStoneGathering::suitablePick));
        c.assertTrue(e.beginStair(),"Safe supported stair refused");
        for(int t=2;t<125;t++)c.runAtTick(t,e::tick);
        c.runAtTick(135,()->{
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(next.down())).isAir(),"Stair step not removed");
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(next.down(2))).isOf(Blocks.DIRT),"Excavated the stair footing");
            c.assertTrue(c.getWorld().getBlockState(c.getAbsolutePos(new BlockPos(4,1,4))).isOf(Blocks.DIRT),"Excavated NPC support");
            c.complete();
        });
    }
}
