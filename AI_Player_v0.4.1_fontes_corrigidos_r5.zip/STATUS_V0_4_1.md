# AI Player v0.4.1-dev — r5

Implementados: pedra somente em caverna com diálogo de orientação; revisão da subida para troncos altos, materiais de apoio e interferência de movimento.

38 testes de comandos e 110 verificações de prioridades aprovados; sintaxe de 36 arquivos Java verificada. Compilação Fabric e 73 GameTests pendentes: download do Gradle bloqueado pela rede. Resultados da r4 não certificam esta revisão. Leia docs/VALIDACAO_V0_4_1.md.
