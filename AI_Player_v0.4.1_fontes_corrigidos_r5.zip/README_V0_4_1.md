# AI Player v0.4.1-dev — r5

Minecraft Java 1.20.1 / Fabric / Java 17. Base: r4. Sem novas dependências.

- Pedra somente sob cobertura natural de caverna. Ao ar livre, pede que o jogador o leve até uma caverna e repita a ordem. Não inicia escada de mineração na superfície.
- Subida para madeira usa também tábuas e pode emprestar o último bloco disponível, com recuperação física dos apoios.
- Centralização/salto não disputam movimento com comandos residuais ou recuperação genérica de terreno.
- 73 GameTests incluídos (três regressões novas). Execução desta revisão ainda pendente; relatório em docs/VALIDACAO_V0_4_1.md.

## Compilar

Extraia todos os arquivos na raiz do repositório, incluindo `.github/workflows/build-fabric.yml`, e execute o workflow. Se usar ZIP na raiz, o workflow precisa já ser o incluído neste pacote; enviar somente o ZIP não atualiza workflows antigos. Se houver fontes extraídos na raiz, eles têm preferência sobre o ZIP.

```sh
bash gradlew clean build compileTestmodJava runGametest --no-daemon
```

JAR resultante: build/libs/ai-player-0.4.1-dev.jar. Este download contém fontes completos, não o JAR do mod. O número interno continua 0.4.1-dev; r5 identifica esta revisão. Documentos e XMLs de revisões anteriores são históricos.
