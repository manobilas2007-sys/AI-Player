# AI Player 0.4.1-dev — relatório de validação

Data: 21/10/2026.

## Evidências de execuções anteriores (v0.4.0)

A execução pública `https://github.com/manobilas2007-sys/AI-Player/actions/runs/39597570207` compilou v0.4.0 com Java 17 / Fabric e executou **64 GameTests**. **62 aprovados, 2 reprovados**:

- `worldregressiontests.waitmoderecoverstalltowerandcollectsalldrops` — um suporte da torre não tinha sido recuperado.
- `surfaceminingtests.autonomousthreestonetools` — faltava um pedregulho para concluir a terceira ferramenta; o coordenador ficava em `Recuperar bancada`.

O `docs/gametest-results-v0.4.0.xml` e a afirmação de 64/64 do Work pertencem a uma execução anterior distinta; **não provam que a revisão v0.4.1 passou**. O workflow antigo `Compilar AI Player` não reconhecia o ZIP pelo nome; erro independente da compilação.

## Execuções locais efetivas desta v0.4.1

- 38/38 testes independentes `PortugueseOrderParserTest`: **APROVADOS** com Java disponível neste ambiente.
- 110/110 verificações `DecisionPolicyTest`: **APROVADAS**.
- Parser de Java com `--release 17`, 36 arquivos Java de `src/`: **APROVADO** (somente sintaxe, não compilação com Fabric).
- Estrutura Gradle, recursos e registro dos 4 provedores de GameTest: verificação estática.
- 65 GameTests declarados, incluindo a nova regressão `ownedBenchRecoveryYieldsToMissingCobblestone`: **NÃO EXECUTADOS nesta revisão**.
- `bash gradlew --version`: **NÃO INICIOU**; resolução DNS de `services.gradle.org` falhou. O ambiente também não continha a distribuição Gradle em cache, o JDK instalado era 21 em vez de 17. Logo, não foi possível compilar/modificar o servidor Minecraft nesta sessão.

## Limitações pendentes

Compilação Fabric real, remapeamento do JAR e 65 GameTests da v0.4.1 precisam ser executados em runner com Java 17 e dependências disponíveis. Além disso, testar a recuperação de torres e navegação no Fold Craft Launcher com o mod instalado. Nenhum teste GameTest foi sinalizado como aprovado sem execução.
