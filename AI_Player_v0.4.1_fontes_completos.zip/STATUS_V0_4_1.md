# Status — AI Player v0.4.1-dev

Fonte oficial: ZIP mais recente fornecido pelo usuário da v0.4.0 Work, com correções pontuais nas classes `CompanionIntelligence`, `StarterCrafting`, `TemporaryPillar`, nos GameTests e no workflow.

**Validação real nesta sessão:** 38 testes de comandos + 110 de prioridade + parsing de 36 fontes Java 17 aprovados.

**Pendente:** compilação completa Gradle/Fabric e 65 GameTests no Minecraft. Sem confirmação de 65/65. Ver docs/VALIDACAO_V0_4_1.md.
